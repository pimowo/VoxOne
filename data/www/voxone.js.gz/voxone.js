window.VoxOneRestartWaiter = Object.freeze({
  create({probe, now = () => Date.now(), sleep = delay => new Promise(resolve => setTimeout(resolve, delay))}) {
    let generation = 0;
    let activeController = null;
    const cancel = () => {
      ++generation;
      if (activeController) activeController.abort();
      activeController = null;
    };
    const wait = async ({previousBootId, timeout = 30000, interval = 500,
                         requestTimeout = 2500}) => {
      cancel();
      const currentGeneration = generation;
      const deadline = now() + timeout;
      while (now() < deadline) {
        const controller = new AbortController();
        activeController = controller;
        const probeTimeout = setTimeout(() => controller.abort(),
          Math.min(requestTimeout, deadline - now()));
        try {
          const readiness = await probe(controller.signal);
          if (currentGeneration !== generation) return {status: "cancelled"};
          if (readiness?.ready === true && readiness.bootId &&
              readiness.bootId !== previousBootId) {
            activeController = null;
            return {status: "ready", bootId: readiness.bootId};
          }
        } catch (_) {
          if (currentGeneration !== generation) return {status: "cancelled"};
        } finally {
          clearTimeout(probeTimeout);
          if (activeController === controller) activeController = null;
        }
        const remaining = deadline - now();
        if (remaining > 0) await sleep(Math.min(interval, remaining));
        if (currentGeneration !== generation) return {status: "cancelled"};
      }
      return {status: "timeout"};
    };
    return {wait, cancel};
  }
});

(() => {
  "use strict";

  const securityGate = document.getElementById("security-gate");
  const appShell = document.getElementById("app-shell");
  const securityApiWarning = document.getElementById("security-api-warning");
  const securityViews = [...securityGate.querySelectorAll(".security-view")];
  const securitySetupForm = document.getElementById("security-setup-form");
  const securityPasswordFields = document.getElementById("security-password-fields");
  const securitySetupPassword = document.getElementById("security-setup-password");
  const securitySetupRepeat = document.getElementById("security-setup-repeat");
  const securityWeakWarning = document.getElementById("security-weak-warning");
  const securityOpenConfirmWrap = document.getElementById("security-open-confirm-wrap");
  const securityOpenConfirm = document.getElementById("security-open-confirm");
  const securitySetupMessage = document.getElementById("security-setup-message");
  const securitySetupSubmit = document.getElementById("security-setup-submit");
  const securitySetupLater = document.getElementById("security-setup-later");
  const securityLoginForm = document.getElementById("security-login-form");
  const securityLoginPassword = document.getElementById("security-login-password");
  const securityLoginMessage = document.getElementById("security-login-message");
  const securityLoginSubmit = document.getElementById("security-login-submit");
  const securityLogout = document.getElementById("security-logout");
  const securityPasswordToggles = [...document.querySelectorAll(".security-password-toggle")];
  const securitySaveConfirmation = document.getElementById("security-save-confirmation");
  const securityManagementForm = document.getElementById("security-management-form");
  const securityManagementCurrentWrap = document.getElementById("security-management-current-wrap");
  const securityManagementCurrent = document.getElementById("security-management-current");
  const securityManagementMode = document.getElementById("security-management-mode");
  const securityManagementPasswordFields = document.getElementById("security-management-password-fields");
  const securityManagementPassword = document.getElementById("security-management-password");
  const securityManagementRepeat = document.getElementById("security-management-repeat");
  const securityManagementMessage = document.getElementById("security-management-message");
  const securityManagementSummary = document.getElementById("security-management-summary");
  const securityManagementSubmit = document.getElementById("security-management-submit");
  let securityRequestGeneration = 0;
  let securityBusy = false;
  let securityConfirmationTimer = 0;
  let securityManagementNeedsAuthentication = false;

  function securityFetch(url, options = {}, timeout = 10000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    return fetch(url, {...options, signal: controller.signal})
      .finally(() => clearTimeout(timer));
  }

  function passwordToggleFor(input) {
    return securityPasswordToggles.find(button =>
      button.dataset.passwordTarget === input.id);
  }

  function setPasswordVisible(input, visible, restoreFocus = false) {
    const button = passwordToggleFor(input);
    if (!button) return;
    const start = input.selectionStart;
    const end = input.selectionEnd;
    const direction = input.selectionDirection;
    input.type = visible ? "text" : "password";
    button.setAttribute("aria-pressed", visible ? "true" : "false");
    button.setAttribute("aria-label", visible ? "Ukryj hasło" : "Pokaż hasło");
    if (restoreFocus) {
      input.focus({preventScroll: true});
      if (start !== null && end !== null)
        input.setSelectionRange(start, end, direction || "none");
    }
  }

  function clearPasswordInput(input) {
    input.value = "";
    setPasswordVisible(input, false);
  }

  function desktopPasswordFocusAllowed() {
    return typeof window.matchMedia === "function" &&
      window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  }

  function visibleFocusedControl() {
    const active = document.activeElement;
    return active && active !== document.body && active !== document.documentElement &&
      securityGate.contains(active) && !active.closest("[hidden]");
  }

  function focusLoginPasswordOnDesktop() {
    if (!desktopPasswordFocusAllowed() || visibleFocusedControl()) return;
    if (!securityLoginForm.hidden)
      securityLoginPassword.focus({preventScroll: true});
  }

  function showSecuritySaveConfirmation() {
    clearTimeout(securityConfirmationTimer);
    securitySaveConfirmation.hidden = false;
    securityConfirmationTimer = setTimeout(() => {
      securitySaveConfirmation.hidden = true;
    }, 5000);
  }

  function validUnicode(value) {
    for (let index = 0; index < value.length; ++index) {
      const unit = value.charCodeAt(index);
      if (unit >= 0xd800 && unit <= 0xdbff) {
        if (++index >= value.length) return false;
        const low = value.charCodeAt(index);
        if (low < 0xdc00 || low > 0xdfff) return false;
      } else if (unit >= 0xdc00 && unit <= 0xdfff) {
        return false;
      }
    }
    return true;
  }

  function securityPasswordInfo(value) {
    const characters = validUnicode(value) ? Array.from(value).length : 0;
    const bytes = validUnicode(value) ? new TextEncoder().encode(value).length : 0;
    return {
      valid: validUnicode(value) && characters >= 4 && bytes <= 64,
      weak: validUnicode(value) && characters >= 4 && characters <= 7 && bytes <= 64,
      characters, bytes
    };
  }

  function setSecurityMessage(element, message, error = true) {
    element.textContent = message;
    element.dataset.kind = error && message ? "error" : "status";
  }

  function showSecurityView(id) {
    applicationAuthorized = false;
    clearTimeout(reconnectTimer);
    if (socket) socket.close();
    appShell.hidden = true;
    securityGate.hidden = false;
    securityApiWarning.hidden = true;
    for (const view of securityViews) view.hidden = view.id !== id;
  }

  function showApplication({warning = "", authenticated = false} = {}) {
    applicationAuthorized = true;
    securityGate.hidden = true;
    appShell.hidden = false;
    securityLogout.hidden = !authenticated;
    securityApiWarning.textContent = warning;
    securityApiWarning.hidden = !warning;
    if (!socket) connect();
  }

  function renderSecurityModeFields() {
    const mode = securitySetupForm.elements["security-mode"].value;
    const protectedMode = mode === "protected";
    securityPasswordFields.hidden = !protectedMode;
    securityOpenConfirmWrap.hidden = protectedMode;
    securitySetupPassword.disabled = !protectedMode;
    securitySetupRepeat.disabled = !protectedMode;
    passwordToggleFor(securitySetupPassword).disabled = !protectedMode;
    passwordToggleFor(securitySetupRepeat).disabled = !protectedMode;
    securityOpenConfirm.disabled = protectedMode;
    if (protectedMode) securityOpenConfirm.checked = false;
    securityWeakWarning.hidden = !protectedMode ||
      !securityPasswordInfo(securitySetupPassword.value).weak;
    setSecurityMessage(securitySetupMessage, "", false);
  }

  function renderSecurityState(state) {
    const known = ["unconfigured", "legacy-unclaimed", "protected", "open", "locked"];
    if (!state || !known.includes(state.state)) throw new Error("invalid security state");
    const modes = ["disabled", "test", "production"];
    const enforcementMode = state.enforcementMode === undefined
      ? (state.protectionEnforced === true ? "production" : "disabled")
      : state.enforcementMode;
    if (!modes.includes(enforcementMode) ||
        state.protectionEnforced !== (enforcementMode !== "disabled"))
      throw new Error("inconsistent security enforcement state");
    securityLogout.hidden = true;
    renderSecurityManagement(state);
    if (state.state === "legacy-unclaimed") {
      if (state.setupAllowed !== true) throw new Error("inconsistent setup state");
      showSecurityView("security-setup-form");
      renderSecurityModeFields();
      return;
    }
    if (state.state === "protected") {
      if (enforcementMode === "disabled") {
        showApplication({warning: "Hasło jest skonfigurowane, ale ochrona dostępu nie jest aktywna w tym firmware."});
        return;
      }
      if (state.authenticated === true) {
        showApplication({authenticated: true, warning: enforcementMode === "test"
          ? "Ochrona dostępu działa w trybie testowym, nie produkcyjnym." : ""});
      } else {
        if (state.loginAllowed !== true) throw new Error("inconsistent login state");
        showSecurityView("security-login-form");
        focusLoginPasswordOnDesktop();
      }
      return;
    }
    if (state.state === "open") {
      showApplication();
      return;
    }
    showSecurityView(state.state === "locked" ? "security-locked" :
      "security-unconfigured");
  }

  function renderSecurityManagement(state) {
    if (!securityManagementForm) return;
    const manageable = state?.state === "open" || state?.state === "protected";
    securityManagementNeedsAuthentication = state?.state === "protected" &&
      state.authenticated !== true;
    securityManagementForm.hidden = !manageable;
    securityManagementCurrentWrap.hidden = !securityManagementNeedsAuthentication;
    securityManagementCurrent.disabled = !securityManagementNeedsAuthentication;
    securityManagementSummary.textContent = state?.state === "protected"
      ? "Panel jest chroniony hasłem. Możesz zmienić hasło albo wyłączyć ochronę."
      : state?.state === "open"
        ? "Panel działa bez hasła. Możesz włączyć ochronę, ustawiając hasło."
        : "Zarządzanie ochroną wymaga normalnego uruchomienia i autoryzacji.";
    securityManagementMode.value = "protected";
    renderSecurityManagementFields();
  }

  function renderSecurityManagementFields() {
    const protectedMode = securityManagementMode.value === "protected";
    securityManagementPasswordFields.hidden = !protectedMode;
    securityManagementPassword.disabled = !protectedMode;
    securityManagementRepeat.disabled = !protectedMode;
    setSecurityMessage(securityManagementMessage, "", false);
  }

  async function submitSecurityManagement(event) {
    event.preventDefault();
    if (securityBusy) return;
    const mode = securityManagementMode.value;
    const currentPassword = securityManagementNeedsAuthentication
      ? securityManagementCurrent.value : "";
    if (securityManagementNeedsAuthentication &&
        !securityPasswordInfo(currentPassword).valid) {
      setSecurityMessage(securityManagementMessage,
        "Podaj prawidłowe bieżące hasło, aby autoryzować zmianę.");
      return;
    }
    const params = new URLSearchParams();
    params.set("mode", mode);
    if (mode === "protected") {
      const info = securityPasswordInfo(securityManagementPassword.value);
      if (!info.valid) {
        setSecurityMessage(securityManagementMessage,
          info.bytes > 64 ? "Hasło przekracza 64 bajty UTF-8." :
          "Hasło musi zawierać co najmniej 4 znaki Unicode.");
        return;
      }
      if (securityManagementPassword.value !== securityManagementRepeat.value) {
        setSecurityMessage(securityManagementMessage, "Wpisane hasła nie są identyczne.");
        return;
      }
      params.set("password", securityManagementPassword.value);
    }
    let body = params.toString();
    let loginBody = securityManagementNeedsAuthentication
      ? new URLSearchParams({password: currentPassword}).toString() : "";
    clearPasswordInput(securityManagementCurrent);
    clearPasswordInput(securityManagementPassword);
    clearPasswordInput(securityManagementRepeat);
    securityBusy = true;
    securityManagementSubmit.disabled = true;
    try {
      if (loginBody) {
        const loginResponse = await securityFetch("/api/security/login", {
          method: "POST", credentials: "same-origin", cache: "no-store",
          headers: {"Content-Type": "application/x-www-form-urlencoded"},
          body: loginBody
        });
        loginBody = "";
        if (!loginResponse.ok) {
          setSecurityMessage(securityManagementMessage,
            await securityErrorMessage(loginResponse, "Autoryzacja nie powiodła się."));
          return;
        }
      }
      const response = await securityFetch("/api/security/manage", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: {"Content-Type": "application/x-www-form-urlencoded"}, body
      });
      body = "";
      if (!response.ok) {
        setSecurityMessage(securityManagementMessage,
          await securityErrorMessage(response, "Nie udało się zapisać ochrony."));
        return;
      }
      showSecuritySaveConfirmation();
      await refreshSecurityState();
    } catch (_) {
      body = "";
      loginBody = "";
      setSecurityMessage(securityManagementMessage, "Brak połączenia z urządzeniem.");
    } finally {
      securityBusy = false;
      securityManagementSubmit.disabled = false;
    }
  }

  async function refreshSecurityState() {
    const generation = ++securityRequestGeneration;
    try {
      const response = await securityFetch("/api/security/state", {
        cache: "no-store", credentials: "same-origin"
      }, 5000);
      if (generation !== securityRequestGeneration) return;
      if (!response.ok) throw new Error("HTTP " + response.status);
      const state = await response.json();
      if (generation !== securityRequestGeneration) return;
      renderSecurityState(state);
    } catch (_) {
      if (generation !== securityRequestGeneration) return;
      showApplication({warning: "Nie udało się odczytać stanu ochrony. Panel pozostaje dostępny, aby zachować możliwość aktualizacji urządzenia."});
    }
  }

  async function securityErrorMessage(response, fallback) {
    let code = "";
    try { code = (await response.json())?.error || ""; } catch (_) {}
    if (response.status === 429 || code === "rate_limited") {
      const retry = response.headers?.get?.("Retry-After");
      return retry ? "Zbyt wiele nieudanych prób. Spróbuj ponownie za " + retry + " s."
        : "Zbyt wiele nieudanych prób. Spróbuj ponownie później.";
    }
    if (response.status === 401 || code === "authentication_failed")
      return "Nieprawidłowe hasło.";
    if (response.status === 409 || code === "invalid_state")
      return "Stan ochrony zmienił się. Odświeżam dane urządzenia.";
    if (code === "invalid_password") return "Hasło nie spełnia wymagań.";
    if (response.status === 403) return "Żądanie zostało odrzucone przez ochronę Host/Origin.";
    return fallback;
  }

  async function submitSecuritySetup(event) {
    event.preventDefault();
    if (securityBusy) return;
    const mode = securitySetupForm.elements["security-mode"].value;
    const params = new URLSearchParams();
    params.set("mode", mode);
    if (mode === "protected") {
      const info = securityPasswordInfo(securitySetupPassword.value);
      if (!info.valid) {
        setSecurityMessage(securitySetupMessage,
          info.bytes > 64 ? "Hasło przekracza 64 bajty UTF-8." :
          "Hasło musi zawierać co najmniej 4 znaki Unicode.");
        return;
      }
      if (securitySetupPassword.value !== securitySetupRepeat.value) {
        setSecurityMessage(securitySetupMessage, "Wpisane hasła nie są identyczne.");
        return;
      }
      params.set("password", securitySetupPassword.value);
    } else if (mode === "open") {
      if (!securityOpenConfirm.checked) {
        setSecurityMessage(securitySetupMessage,
          "Potwierdź świadomy wybór panelu bez hasła.");
        return;
      }
    } else {
      setSecurityMessage(securitySetupMessage, "Nieznany tryb ochrony.");
      return;
    }

    securityBusy = true;
    securitySetupSubmit.disabled = true;
    let body = params.toString();
    clearPasswordInput(securitySetupPassword);
    clearPasswordInput(securitySetupRepeat);
    securityWeakWarning.hidden = true;
    try {
      const response = await securityFetch("/api/security/setup", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: {"Content-Type": "application/x-www-form-urlencoded"}, body
      });
      body = "";
      if (!response.ok) {
        setSecurityMessage(securitySetupMessage,
          await securityErrorMessage(response, "Nie udało się zapisać trybu ochrony."));
        if (response.status === 409) await refreshSecurityState();
        return;
      }
      let confirmation = null;
      try { confirmation = await response.json(); } catch (_) {}
      if (confirmation?.ok !== true) {
        setSecurityMessage(securitySetupMessage,
          "Urządzenie nie potwierdziło zapisu ustawień ochrony.");
        return;
      }
      await refreshSecurityState();
      showSecuritySaveConfirmation();
    } catch (_) {
      body = "";
      setSecurityMessage(securitySetupMessage,
        "Brak połączenia z urządzeniem. Tryb ochrony nie został potwierdzony.");
    } finally {
      securityBusy = false;
      securitySetupSubmit.disabled = false;
    }
  }

  async function submitSecurityLogin(event) {
    event.preventDefault();
    if (securityBusy) return;
    const info = securityPasswordInfo(securityLoginPassword.value);
    if (!info.valid) {
      setSecurityMessage(securityLoginMessage,
        info.bytes > 64 ? "Hasło przekracza 64 bajty UTF-8." :
        "Podaj hasło zawierające co najmniej 4 znaki Unicode.");
      return;
    }
    const params = new URLSearchParams();
    params.set("password", securityLoginPassword.value);
    let body = params.toString();
    clearPasswordInput(securityLoginPassword);
    securityBusy = true;
    securityLoginSubmit.disabled = true;
    try {
      const response = await securityFetch("/api/security/login", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: {"Content-Type": "application/x-www-form-urlencoded"}, body
      });
      body = "";
      if (!response.ok) {
        setSecurityMessage(securityLoginMessage,
          await securityErrorMessage(response, "Logowanie nie powiodło się."));
        return;
      }
      setSecurityMessage(securityLoginMessage, "", false);
      await refreshSecurityState();
    } catch (_) {
      body = "";
      setSecurityMessage(securityLoginMessage,
        "Brak połączenia z urządzeniem. Spróbuj ponownie.");
    } finally {
      securityBusy = false;
      securityLoginSubmit.disabled = false;
    }
  }

  async function logoutSecuritySession() {
    if (securityBusy) return;
    securityBusy = true;
    securityLogout.disabled = true;
    try {
      await securityFetch("/api/security/logout", {
        method: "POST", credentials: "same-origin", cache: "no-store"
      });
    } catch (_) {
      // Refresh still determines whether the server retained the session.
    } finally {
      securityBusy = false;
      securityLogout.disabled = false;
      await refreshSecurityState();
    }
  }

  window.VoxOneSecurityUi = Object.freeze({
    refresh: refreshSecurityState,
    passwordInfo: securityPasswordInfo
  });

  const tabs = ["status", "stations", "audio", "dsp", "settings", "hardware", "system", "update"];
  const updateImages = {
    firmware: {
      file: document.getElementById("update-firmware-file"),
      name: document.getElementById("update-firmware-name"),
      button: document.getElementById("update-firmware-button")
    },
    spiffs: {
      file: document.getElementById("update-spiffs-file"),
      name: document.getElementById("update-spiffs-name"),
      button: document.getElementById("update-spiffs-button")
    }
  };
  const updateStatus = document.getElementById("update-status");
  const updateProgress = document.getElementById("update-progress");
  const updateBtFile = document.getElementById("update-bt-file");
  const updateBtFileName = document.getElementById("update-bt-file-name");
  const updateBtButton = document.getElementById("update-bt-button");
  let updateBusy = false;
  const readDeviceReadiness = async signal => {
    const response = await fetch("/api/ready?update=" + Date.now(), {
      cache: "no-store", signal
    });
    if (!response.ok) throw new Error("HTTP " + response.status);
    const readiness = await response.json();
    if (readiness?.ready !== true || typeof readiness.bootId !== "string" ||
        !readiness.bootId) throw new Error("invalid readiness response");
    return readiness;
  };
  const updateRestartWaiter = window.VoxOneRestartWaiter.create({probe: readDeviceReadiness});
  let btUpdateBusy = false;
  let btUpdatePolling = false;
  let btHttpUploading = false;
  const rebootButton = document.getElementById("reboot-button");
  const rebootDialog = document.getElementById("reboot-dialog");
  const rebootCancel = document.getElementById("reboot-cancel");
  const rebootConfirm = document.getElementById("reboot-confirm");
  const rebootStatus = document.getElementById("reboot-status");
  let rebootStarted = false;
  const configBackupButton = document.getElementById("config-backup-button");
  const configBackupStatus = document.getElementById("config-backup-status");
  const configRestoreFile = document.getElementById("config-restore-file");
  const configRestoreName = document.getElementById("config-restore-name");
  const configRestoreButton = document.getElementById("config-restore-button");
  const configRestoreRestart = document.getElementById("config-restore-restart");
  const configRestoreStatus = document.getElementById("config-restore-status");
  let configTransferBusy = false;
  const buttons = {
    prev: document.getElementById("prev-button"),
    play: document.getElementById("play-button"),
    next: document.getElementById("next-button")
  };
  const sourceSelector = document.getElementById("source-selector");
  const volumeSliders = [
    document.getElementById("volume-slider"),
    document.getElementById("audio-volume-slider")
  ];
  const muteButtons = [...document.querySelectorAll(".mute-button")];
  const maximumVolumeSlider = document.getElementById("maximum-volume-slider");
  const maximumVolumeValue = document.getElementById("maximum-volume-value");
  const startupModeSelect = document.getElementById("startup-mode-select");
  const startupFixedControl = document.getElementById("startup-fixed-control");
  const startupFixedSlider = document.getElementById("startup-fixed-slider");
  const startupFixedValue = document.getElementById("startup-fixed-value");
  const volumeSettingsPending = document.getElementById("volume-settings-pending");
  const displaySettingsCard = document.getElementById("display-settings-card");
  const flipScreenControl = document.getElementById("flip-screen-control");
  const flipScreenToggle = document.getElementById("flip-screen-toggle");
  const flipScreenFeedback = document.getElementById("flip-screen-feedback");
  const vuMeterControl = document.getElementById("vu-meter-control");
  const vuMeterToggle = document.getElementById("vu-meter-toggle");
  const vuMeterValue = document.getElementById("vu-meter-value");
  const brightnessControl = document.getElementById("brightness-control");
  const brightnessUnavailable = document.getElementById("brightness-unavailable");
  const brightnessSlider = document.getElementById("brightness-slider");
  const brightnessValue = document.getElementById("brightness-value");
  const autoReturnControl = document.getElementById("auto-return-control");
  const stationListTimeoutInput = document.getElementById("station-list-timeout");
  const btTimeoutControl = document.getElementById("bt-timeout-control");
  const btTransportTimeoutInput = document.getElementById("bt-transport-timeout");
  const scrollSettingsForm = document.getElementById("scroll-settings-form");
  const scrollEnabledSelect = document.getElementById("scroll-enabled");
  const scrollPauseSelect = document.getElementById("scroll-pause");
  const scrollSpeedSelect = document.getElementById("scroll-speed");
  const scrollSettingsStatus = document.getElementById("scroll-settings-status");
  const scrollSettingsSource = document.getElementById("scroll-settings-source");
  const scrollSettingsSave = document.getElementById("scroll-settings-save");
  const scrollReadablePauseValues = [0, 1000, 2000, 2500, 3000, 4000, 5000];
  const scrollWritablePauseValues = [0, 1000, 2000, 3000, 4000, 5000];
  const rtcCard = document.getElementById("rtc-card");
  const rtcNtpInterval = document.getElementById("rtc-ntp-interval");
  const rtcWriteInterval = document.getElementById("rtc-write-interval");
  const rtcSyncNow = document.getElementById("rtc-sync-now");
  const rtcFeedback = document.getElementById("rtc-feedback");
  const audioControls = {
    bass: { slider: document.getElementById("audio-bass-slider"), command: "bass" },
    middle: { slider: document.getElementById("audio-middle-slider"), command: "middle" },
    treble: { slider: document.getElementById("audio-treble-slider"), command: "trebble" },
    balance: { slider: document.getElementById("audio-balance-slider"), command: "balance" }
  };
  const tonePresets = {
    flat: [0, 0, 0],
    bass: [6, -2, 0],
    rock: [5, -2, 4],
    pop: [3, 2, 3],
    mowa: [-4, 4, 2]
  };
  const tonePresetButtons = [...document.querySelectorAll("[data-tone-preset]")];
  const tonePresetUser = document.getElementById("audio-preset-user");
  const myStationsTab = document.getElementById("my-stations-tab");
  const directoryTab = document.getElementById("directory-tab");
  const myStationsView = document.getElementById("my-stations-view");
  const directoryView = document.getElementById("directory-view");
  const directoryForm = document.getElementById("directory-form");
  const directoryQuery = document.getElementById("directory-query");
  const directoryCountry = document.getElementById("directory-country");
  const directorySearchButton = document.getElementById("directory-search");
  const directoryStatus = document.getElementById("directory-status");
  const directoryResults = document.getElementById("directory-results");
  let directoryBusy = false;
  let directoryStations = [];
  const stationList = document.getElementById("station-list");
  const stationSearch = document.getElementById("station-search");
  const stationClear = document.getElementById("station-search-clear");
  const stationRetry = document.getElementById("stations-retry");
  const stationAdd = document.getElementById("station-add");
  const stationImport = document.getElementById("station-import");
  const stationExport = document.getElementById("station-export");
  const stationImportFile = document.getElementById("station-import-file");
  const stationImportDialog = document.getElementById("station-import-dialog");
  const stationImportDetails = document.getElementById("station-import-details");
  const stationImportWarning = document.getElementById("station-import-warning");
  const stationImportCancel = document.getElementById("station-import-cancel");
  const stationImportConfirm = document.getElementById("station-import-confirm");
  const stationSaving = document.getElementById("stations-saving");
  const stationFeedback = document.getElementById("stations-feedback");
  const stationDialog = document.getElementById("station-dialog");
  const stationForm = document.getElementById("station-form");
  const stationName = document.getElementById("station-name");
  const stationUrl = document.getElementById("station-url");
  const stationOvol = document.getElementById("station-ovol");
  const stationFormError = document.getElementById("station-form-error");
  const stationCancel = document.getElementById("station-cancel");
  const stationSave = document.getElementById("station-save");
  const mqttForm = document.getElementById("mqtt-form");
  const mqttEnabled = document.getElementById("mqtt-enabled");
  const mqttFields = document.getElementById("mqtt-fields");
  const mqttHost = document.getElementById("mqtt-host");
  const mqttPort = document.getElementById("mqtt-port");
  const mqttUsername = document.getElementById("mqtt-username");
  const mqttPassword = document.getElementById("mqtt-password");
  const mqttPasswordState = document.getElementById("mqtt-password-state");
  const mqttClearPassword = document.getElementById("mqtt-clear-password");
  const mqttCustomRootWrap = document.getElementById("mqtt-custom-root-wrap");
  const mqttRootTopic = document.getElementById("mqtt-root-topic");
  const mqttEffectiveRoot = document.getElementById("mqtt-effective-root");
  const mqttRootModeLabel = document.getElementById("mqtt-root-mode-label");
  const mqttTopicList = document.getElementById("mqtt-topic-list");
  const mqttFeedback = document.getElementById("mqtt-feedback");
  const mqttSave = document.getElementById("mqtt-save");
  const haName = document.getElementById("ha-name");
  const haYaml = document.getElementById("ha-yaml");
  const haCopy = document.getElementById("ha-copy");
  const haCopyStatus = document.getElementById("ha-copy-status");
  const hardwareForm = document.getElementById("hardware-form");
  const hardwareDisplay = document.getElementById("hardware-display");
  const hardwareInput = document.getElementById("hardware-input");
  const hardwareAudio = document.getElementById("hardware-audio");
  const hardwareSaveRestart = document.getElementById("hardware-save-restart");
  const hardwareFeedback = document.getElementById("hardware-feedback");
  const hardwareDirtyBadge = document.getElementById("hardware-dirty-badge");
  let mqttConfigLoaded = false;
  let mqttPasswordSet = false;
  let mqttEffectiveRootValue = "";
  let mqttSaving = false;
  let rtcSyncing = false;
  let rtcStatusLoading = false;
  let hardwareConfigLoaded = false;
  let hardwareSaving = false;
  let savedHardwareConfig = null;
  const state = {
    connection: "connecting",
    webStatus: null,
    systemInfo: null,
    networkInfo: null,
    source: null,
    station: null,
    metadata: null,
    codec: null,
    bitrate: null,
    rssi: null,
    volume: null,
    volume100: null,
    muted: null,
    maximumVolume: null,
    startupMode: null,
    startupFixedVolume: null,
    brightness: null,
    canBrightness: false,
    stationListTimeout: null,
    btTransportTimeout: null,
    canBtTransport: false,
    flip: null,
    canFlip: false,
    vu: null,
    canVu: false,
    canScrollSettings: false,
    scrollEnabled: null,
    scrollSpeed: null,
    scrollPauseMs: null,
    scrollSettingsSource: null,
    scrollCoreActive: false,
    bass: null,
    middle: null,
    treble: null,
    balance: null,
    playing: null,
    current: null,
    stations: [],
    stationsStatus: "idle",
    stationQuery: "",
    count: 0,
    revision: null,
    pendingMetadataNumber: null,
    loading: false,
    mutationInProgress: false,
    importing: false,
    error: "",
    notice: "",
    editorNumber: null,
    ip: null,
    profile: typeof voxOneProfile === "string" ? voxOneProfile : null,
    version: typeof voxOneVersion === "string" ? voxOneVersion : null,
    channel: typeof voxOneChannel === "string" ? voxOneChannel : null,
    build: typeof voxOneBuild === "string" ? voxOneBuild : null,
    baseVersion: typeof yoRadioVersion === "string" ? yoRadioVersion : null
  };
  const advancedAudio = window.createAdvancedAudioLive(
    document.getElementById("advanced-audio-root"),
    { getShared: () => state, send: (command, value) => send(command, value) }
  );
  let dspTabActive = false;

  let socket = null;
  let applicationAuthorized = false;
  let reconnectTimer = 0;
  let reconnectDelay = 1000;
  let extraSyncTimer = 0;
  let systemInfoTimer = 0;
  let extraSyncSent = false;
  let volumeTimer = 0;
  let volumeAckTimer = 0;
  let lastVolumeSentAt = 0;
  let pendingVolume = null;
  let awaitingVolume = null;
  const volumeSettingEditing = { maximumVolume: null, startupMode: null, startupFixedVolume: null };
  const volumeSettingTimers = { maximumVolume: 0, startupMode: 0, startupFixedVolume: 0 };
  const volumeSettingDragging = { maximumVolume: false, startupFixedVolume: false };
  let draggingVolume = false;
  let activeVolumeSlider = null;
  let leaving = false;
  let wsCurrentSequence = 0;
  let flipPending = false;
  let flipTimer = 0;
  let vuAwaiting = null;
  let vuTimer = 0;
  let brightnessDragging = false;
  let brightnessPending = null;
  let brightnessAwaiting = null;
  let brightnessTimer = 0;
  let brightnessAckTimer = 0;
  let lastBrightnessSentAt = 0;
  let scrollSettingsDirty = false;
  let scrollSettingsSaving = false;
  let scrollSettingsPending = null;
  let scrollSettingsTimer = 0;
  let scrollSettingsFeedback = "";
  let scrollSettingsFeedbackError = false;

  function text(id, value) {
    const node = document.getElementById(id);
    if (node && node.textContent !== value) node.textContent = value;
  }

  function renderUpdateFiles() {
    for (const image of Object.values(updateImages)) {
      const file = image.file.files[0];
      image.name.textContent = file ? file.name + " · " +
        (file.size / 1024 / 1024).toFixed(2) + " MB" : "Nie wybrano pliku.";
      image.file.disabled = updateBusy || btUpdateBusy;
      image.button.disabled = updateBusy || btUpdateBusy || !file;
    }
    const file = updateBtFile.files[0];
    const info = state.connection === "connected" ? state.systemInfo : null;
    const module = state.webStatus?.btModule;
    const supported = info?.btFirmwareUpdateSupported === true;
    const ready = supported && Number.isSafeInteger(info.psramFree) &&
      info.psramFree >= (file?.size || 0) + 384 * 1024 &&
      module?.online === true && module?.protocol === 2 &&
      module.capabilities?.split(/\s+/).includes("FW_UPDATE") &&
      state.webStatus?.activeSource !== "bt";
    updateBtFileName.textContent = file ? file.name + " · " +
      (file.size / 1024 / 1024).toFixed(2) + " MB" : "Nie wybrano pliku.";
    updateBtFile.disabled = updateBusy || btUpdateBusy || !supported;
    updateBtButton.disabled = updateBusy || btUpdateBusy || !file || !ready ||
      !file.size || file.size > 1310720;
  }

  function renderBtModule() {
    const module = state.webStatus?.btModule;
    const online = state.connection === "connected" && module?.online === true;
    text("update-bt-online", online ? "Online" : "Offline");
    text("system-bt-online", online ? "TAK" : "NIE");
    text("system-bt-firmware", online && module.firmware ? module.firmware : "—");
    text("system-bt-protocol", online && module.protocol ? String(module.protocol) : "—");
    text("system-bt-name", online && module.name ? module.name : "—");
    text("system-bt-capabilities", online && module.capabilities ? module.capabilities : "—");
  }

  function formatSystemUptime(seconds) {
    if (!Number.isSafeInteger(seconds) || seconds < 0) return "—";
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainder = seconds % 60;
    const clock = [hours, minutes, remainder].map(value => String(value).padStart(2, "0")).join(":");
    return days ? days + " d " + clock : clock;
  }

  function formatHeap(bytes) {
    return Number.isSafeInteger(bytes) && bytes >= 0 ? Math.floor(bytes / 1024) + " kB" : "—";
  }

  function renderSystemInfo() {
    const info = state.connection === "connected" ? state.systemInfo : null;
    text("system-version", state.version ? state.version + (state.channel ? "-" + state.channel : "") : "—");
    text("system-build", state.build || "—");
    text("system-profile", state.profile ? state.profile.toUpperCase() : "—");
    text("system-ip", state.ip || "—");
    text("system-mac", info?.mac || "—");
    const rssi = Number.isInteger(info?.rssi) ? info.rssi : state.rssi;
    text("system-rssi", Number.isInteger(rssi) && rssi > -127 ? rssi + " dBm" : "—");
    text("system-uptime", formatSystemUptime(info?.uptimeSeconds));
    text("system-free-heap", formatHeap(info?.freeHeap));
    text("system-minimum-heap", formatHeap(info?.minimumFreeHeap));
    const psramTotal = info?.psramTotal;
    const psramFree = info?.psramFree;
    text("system-psram", !info ? "—" : Number.isSafeInteger(psramTotal) && psramTotal > 0 &&
      Number.isSafeInteger(psramFree) && psramFree >= 0
      ? (psramTotal / 1048576).toFixed(1) + " MB total / " +
        (psramFree / 1048576).toFixed(1) + " MB free" : "Brak");
    text("system-capabilities", info?.capabilities || "—");
    renderBtModule();
    renderUpdateFiles();
  }

  function renderFooter() {
    const details = document.getElementById("footer-details");
    const connection = document.getElementById("footer-connection");
    if (details) {
      const parts = [state.version ? "VoxOne " + state.version : "VoxOne"];
      if (state.profile) parts.push(state.profile.toUpperCase());
      if (state.connection === "connected" && state.ip) parts.push(state.ip);
      details.textContent = parts.join(" · ");
    }
    if (connection) {
      connection.dataset.state = state.connection;
      connection.textContent = {
        connected: "Połączono",
        connecting: "Łączenie...",
        disconnected: "Rozłączono"
      }[state.connection];
    }
  }

  function renderNetworkInfo() {
    const info = state.connection === "connected" ? state.networkInfo : null;
    text("network-hostname", info?.hostname || "—");
    text("network-active-ssid", info?.activeSsid || "—");
    const list = document.getElementById("network-profiles");
    if (!list) return;
    list.replaceChildren();
    if (!info || !info.profiles.length) {
      const item = document.createElement("li");
      item.className = "muted";
      item.textContent = info ? "Brak zapisanych profili Wi-Fi." : "Oczekiwanie na dane urządzenia.";
      list.append(item);
      return;
    }
    for (const profile of info.profiles) {
      const item = document.createElement("li");
      const active = profile.ssid && profile.ssid === info.activeSsid;
      item.classList.toggle("is-active", active);
      if (active) item.setAttribute("aria-current", "true");
      const name = document.createElement("strong");
      name.textContent = profile.ssid || "(pusty SSID)";
      const detail = document.createElement("span");
      detail.textContent = "Hasło: " + (profile.passwordSet ? "zapisane" : "brak") +
        " · kolejność prób: " + profile.order;
      item.append(name, detail);
      list.append(item);
    }
  }

  function scheduleSystemInfoRefresh() {
    clearTimeout(systemInfoTimer);
    if (!['system', 'settings'].includes(location.hash.slice(1)) || state.connection !== "connected") return;
    send("getsystem", 1);
    send("getrssi", 1);
    systemInfoTimer = setTimeout(scheduleSystemInfoRefresh, 10000);
  }

  function setUpdateStatus(message, error = false) {
    updateStatus.textContent = message;
    updateStatus.dataset.kind = error ? "error" : "status";
  }

  async function waitForDeviceRestart({ delay = 2500, timeout = 30000, onReturn, onTimeout }) {
    await new Promise(resolve => setTimeout(resolve, delay));
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const controller = new AbortController();
      const requestTimeout = setTimeout(() => controller.abort(), 2500);
      try {
        const response = await fetch("/variables.js?update=" + Date.now(), {
          cache: "no-store", signal: controller.signal
        });
        if (response.ok) {
          onReturn();
          return;
        }
      } catch (_) { /* The device may still be restarting. */ }
      finally { clearTimeout(requestTimeout); }
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    onTimeout();
  }

  async function waitForUpdateRestart(previousBootId) {
    setUpdateStatus("Aktualizacja zakończona. Restart urządzenia...");
    const result = await updateRestartWaiter.wait({previousBootId});
    if (result.status === "ready") {
      location.replace("/voxone.html?updated=" + encodeURIComponent(result.bootId) + "#status");
      return;
    }
    if (result.status === "cancelled") return;
    updateBusy = false;
    renderUpdateFiles();
    setUpdateStatus("Urządzenie nie wróciło w ciągu 30 s. Sprawdź połączenie i odśwież stronę.", true);
  }

  function setRebootStatus(message, error = false) {
    rebootStatus.textContent = message;
    rebootStatus.dataset.kind = error ? "error" : "status";
  }

  async function rebootDevice() {
    if (rebootStarted) return;
    rebootStarted = true;
    rebootButton.disabled = true;
    rebootConfirm.disabled = true;
    rebootDialog.close();
    setRebootStatus("Restartowanie urządzenia...");
    if (!send("reboot", 1)) {
      rebootStarted = false;
      rebootButton.disabled = false;
      rebootConfirm.disabled = false;
      setRebootStatus("Brak połączenia z urządzeniem.", true);
      return;
    }
    await waitForDeviceRestart({
      delay: 1200,
      onReturn: () => {
        setRebootStatus("VoxOne uruchomiony");
        setTimeout(() => location.reload(), 700);
      },
      onTimeout: () => setRebootStatus("Nie udało się ponownie połączyć z VoxOne.", true)
    });
  }

  function setConfigTransferStatus(element, message, error = false) {
    element.textContent = message;
    element.dataset.kind = error ? "error" : "status";
  }

  function configRestoreError(error) {
    if (error === "wrong_schema") return "Backup ma nieobsługiwaną wersję schematu.";
    if (error === "bad_crc") return "Backup jest uszkodzony (nieprawidłowy CRC).";
    if (error === "unsupported_hardware")
      return "Backup zawiera konfigurację sprzętu nieobsługiwaną przez to urządzenie.";
    if (error === "recovery_pending")
      return "Przywracanie nie zostało zakończone. Uruchom ponownie urządzenie, aby wykonać recovery.";
    if (error === "backup_too_large") return "Plik backupu przekracza bezpieczny limit rozmiaru.";
    if (error === "restore_failed") return "Nie udało się zapisać przywracanej konfiguracji.";
    if (error === "insufficient_memory") return "Brak pamięci do zweryfikowania backupu.";
    if (error === "reboot_pending") return "Restart urządzenia jest już w toku.";
    return "Nieprawidłowy lub niekompletny plik backupu.";
  }

  async function downloadConfigBackup() {
    if (configTransferBusy) return;
    configTransferBusy = true;
    configBackupButton.disabled = true;
    setConfigTransferStatus(configBackupStatus, "Przygotowywanie backupu...");
    try {
      const response = await fetch("/api/config/backup", {cache: "no-store"});
      if (!response.ok) throw new Error("HTTP " + response.status);
      const blob = await response.blob();
      if (!blob.size) throw new Error("empty backup");
      const disposition = response.headers?.get?.("Content-Disposition") || "";
      const match = disposition.match(/filename="([^"]+)"/i);
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = match ? match[1] : "VoxOne-0.8.0-backup.vxcf";
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(link.href);
      setConfigTransferStatus(configBackupStatus, "Backup został pobrany.");
    } catch (_) {
      setConfigTransferStatus(configBackupStatus, "Nie udało się pobrać backupu.", true);
    } finally {
      configTransferBusy = false;
      configBackupButton.disabled = false;
    }
  }

  async function restoreConfigBackup() {
    if (configTransferBusy) return;
    const file = configRestoreFile.files[0];
    if (!file) return;
    configTransferBusy = true;
    configRestoreButton.disabled = true;
    configRestoreFile.disabled = true;
    configRestoreRestart.hidden = true;
    setConfigTransferStatus(configRestoreStatus, "Walidacja i przywracanie konfiguracji...");
    try {
      const response = await fetch("/api/config/restore", {
        method: "POST",
        headers: {"Content-Type": "application/octet-stream"},
        body: file,
        cache: "no-store"
      });
      const result = await response.json();
      if (!response.ok || result.ok !== true || result.restartRequired !== true) {
        throw new Error(result.error || "invalid_file");
      }
      configRestoreRestart.hidden = false;
      setConfigTransferStatus(configRestoreStatus,
        "Konfiguracja została przywrócona. Wymagane ponowne uruchomienie.");
    } catch (error) {
      setConfigTransferStatus(configRestoreStatus,
        configRestoreError(error.message), true);
    } finally {
      configTransferBusy = false;
      configRestoreFile.disabled = false;
      configRestoreButton.disabled = !configRestoreFile.files.length;
    }
  }

  async function uploadUpdateImage(target) {
    if (updateBusy || btUpdateBusy) return;
    const file = updateImages[target].file.files[0];
    if (!file) return;
    const lowerName = file.name.toLowerCase();
    if (!lowerName.endsWith(".bin") || lowerName.endsWith("full.bin")) {
      setUpdateStatus("Wybierz obraz .bin dla urządzenia. Nie używaj full.bin.", true);
      return;
    }
    if ((target === "firmware" && lowerName.includes("spiffs")) ||
        (target === "spiffs" && lowerName.includes("firmware"))) {
      setUpdateStatus("Nazwa pliku nie pasuje do wybranego rodzaju aktualizacji.", true);
      return;
    }
    if (!file.size) {
      setUpdateStatus("Wybrany plik jest pusty.", true);
      return;
    }
    updateBusy = true;
    updateRestartWaiter.cancel();
    renderUpdateFiles();
    updateProgress.hidden = false;
    updateProgress.value = 0;
    setUpdateStatus("Wysyłanie " + file.name + "...");
    let readiness;
    const readinessController = new AbortController();
    const readinessTimeout = setTimeout(() => readinessController.abort(), 2500);
    try {
      readiness = await readDeviceReadiness(readinessController.signal);
    } catch (_) {
      updateBusy = false;
      renderUpdateFiles();
      updateProgress.hidden = true;
      setUpdateStatus("Nie udało się przygotować monitorowania restartu. Spróbuj ponownie.", true);
      return;
    } finally {
      clearTimeout(readinessTimeout);
    }
    const body = new FormData();
    body.append("updatetarget", target);
    body.append("filesize", String(file.size));
    body.append("update", file, file.name);
    const request = new XMLHttpRequest();
    request.open("POST", "/update");
    const finishTransportFailure = message => {
      updateBusy = false;
      renderUpdateFiles();
      updateProgress.hidden = true;
      updateProgress.value = 0;
      setUpdateStatus(message, true);
    };
    request.upload.addEventListener("progress", event => {
      if (!event.lengthComputable) return;
      const percent = Math.min(100, Math.round(event.loaded * 100 / event.total));
      updateProgress.value = percent;
      setUpdateStatus("Wysyłanie " + file.name + ": " + percent + "%");
    });
    request.upload.addEventListener("load", () => {
      updateProgress.value = 100;
      setUpdateStatus("Walidacja obrazu i zapis aktualizacji...");
    });
    request.addEventListener("load", () => {
      if (request.status === 200 && request.responseText.trim() === "OK") {
        setUpdateStatus("Aktualizacja zakończona.");
        waitForUpdateRestart(readiness.bootId);
        return;
      }
      finishTransportFailure(request.responseText.trim() ||
        "Błąd aktualizacji: HTTP " + request.status);
    });
    request.addEventListener("error", () => {
      finishTransportFailure("Połączenie zostało przerwane. Możesz ponowić aktualizację.");
    });
    request.addEventListener("abort", () => {
      finishTransportFailure("Aktualizacja została przerwana. Możesz spróbować ponownie.");
    });
    request.addEventListener("timeout", () => {
      finishTransportFailure("Upłynął czas wysyłania. Możesz spróbować ponownie.");
    });
    try {
      request.send(body);
    } catch (error) {
      finishTransportFailure("Nie udało się rozpocząć wysyłania: " + error.message);
    }
  }

  async function pollBtUpdate() {
    if (btHttpUploading || btUpdatePolling || state.connection !== "connected" ||
        state.systemInfo?.btFirmwareUpdateSupported !== true) return;
    btUpdatePolling = true;
    try {
      const response = await fetch("/api/bt/update", {cache: "no-store"});
      if (!response.ok) return;
      const progress = await response.json();
      const running = progress.receiving || progress.pending || progress.active;
      if (running) {
        btUpdateBusy = true;
        const phase = ["Przygotowanie", "Wysyłanie do VoxOneBT", "Weryfikacja",
          "Restart VoxOneBT", "Oczekiwanie na VoxOneBT", "Sukces", "Błąd"][progress.phase] || "Aktualizacja";
        setUpdateStatus("VoxOneBT: " + phase + " · ACK " + progress.confirmedBytes +
          "/" + progress.totalBytes + " B (" + progress.percent + "%).");
      } else if (btUpdateBusy) {
        btUpdateBusy = false;
        // BtFirmwareSender::State: Success=9, Error=10, Aborted=11.
        if (progress.state === 9) {
          setUpdateStatus("Aktualizacja VoxOneBT zakończona; wersja potwierdzona po restarcie.");
        } else if (progress.state === 11) {
          setUpdateStatus("Aktualizacja VoxOneBT przerwana.", true);
        } else {
          const reason = progress.startError ||
            (progress.error ? "błąd sendera " + progress.error : "brak kodu błędu sendera");
          setUpdateStatus("Aktualizacja VoxOneBT nie powiodła się: " + reason, true);
        }
      }
      renderUpdateFiles();
    } catch (_) { /* A disconnect does not cancel a transfer owned by MAIN. */ }
    finally { btUpdatePolling = false; }
  }

  function uploadBtFirmware() {
    if (updateBusy || btUpdateBusy || updateBtButton.disabled) return;
    const file = updateBtFile.files[0];
    if (!file || !file.name.toLowerCase().endsWith(".bin") || !file.size ||
        file.size > 1310720) {
      setUpdateStatus("Wybierz firmware.bin VoxOneBT o rozmiarze do 1 310 720 B.", true);
      return;
    }
    btUpdateBusy = true;
    btHttpUploading = true;
    renderUpdateFiles();
    setUpdateStatus("Wysyłanie obrazu VoxOneBT do PSRAM...");
    const body = new FormData();
    body.append("filesize", String(file.size));
    body.append("update", file, file.name);
    const request = new XMLHttpRequest();
    request.open("POST", "/update/bt");
    request.upload.addEventListener("progress", event => {
      if (event.lengthComputable) setUpdateStatus("Odbiór obrazu VoxOneBT: " +
        Math.min(100, Math.round(event.loaded * 100 / event.total)) + "% (HTTP, nie UART).");
    });
    request.addEventListener("load", () => {
      btHttpUploading = false;
      if (request.status === 202 && request.responseText.trim() === "STAGED") {
        setUpdateStatus("Obraz zweryfikowany; oczekiwanie na start sendera VoxOneBT...");
        pollBtUpdate();
      } else {
        btUpdateBusy = false;
        renderUpdateFiles();
        setUpdateStatus(request.responseText.trim() || "Upload VoxOneBT odrzucony.", true);
      }
    });
    request.addEventListener("error", () => {
      btHttpUploading = false;
      btUpdateBusy = false;
      renderUpdateFiles();
      setUpdateStatus("Połączenie przerwane. Sprawdź status urządzenia przed ponowną próbą.", true);
    });
    try { request.send(body); }
    catch (error) {
      btHttpUploading = false;
      btUpdateBusy = false;
      renderUpdateFiles();
      setUpdateStatus("Nie udało się rozpocząć wysyłania: " + error.message, true);
    }
  }

  function showTab() {
    const requested = location.hash.slice(1);
    const selected = tabs.includes(requested) ? requested : "status";
    for (const tab of tabs) {
      document.getElementById(tab).hidden = tab !== selected;
      const link = document.querySelector('[data-tab="' + tab + '"]');
      if (tab === selected) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    }
    if (selected === "stations" && state.stationsStatus === "idle") loadStations();
    if (selected === "settings" && !mqttConfigLoaded) loadMqttConfig();
    if (selected === "settings") loadTimeStatus();
    if (selected === "hardware" && !hardwareConfigLoaded) loadHardwareConfig();
    if (selected === "update") send("getwebstatus", 1);
    if (selected === "dsp") {
      if (!dspTabActive) advancedAudio.enter();
      else advancedAudio.render();
      dspTabActive = true;
    } else if (dspTabActive) {
      advancedAudio.leave();
      dspTabActive = false;
    }
    scheduleSystemInfoRefresh();
  }

  function showStartupTab() {
    history.replaceState(null, "", "#status");
    showTab();
  }

  function setRtcFeedback(message, error = false) {
    rtcFeedback.textContent = message;
    rtcFeedback.dataset.kind = error ? "error" : "status";
  }

  async function loadTimeStatus() {
    if (rtcStatusLoading) return null;
    rtcStatusLoading = true;
    try {
      const response = await fetch("/api/time", { cache: "no-store" });
      if (!response.ok) throw new Error("HTTP " + response.status);
      const status = await response.json();
      rtcCard.hidden = status.rtcSupported !== true;
      if (rtcCard.hidden) return status;
      text("rtc-found", status.rtcFound ? "Wykryty" : "Brak");
      text("rtc-system-time", status.systemTime || "—");
      text("rtc-time", status.rtcTime || "—");
      rtcNtpInterval.value = String(status.timeSyncInterval);
      rtcWriteInterval.value = String(status.timeSyncIntervalRTC);
      rtcNtpInterval.disabled = false;
      rtcWriteInterval.disabled = false;
      rtcSyncNow.disabled = rtcSyncing;
      return status;
    } catch (error) {
      if (!rtcCard.hidden) setRtcFeedback("Nie udało się pobrać stanu RTC: " + (error.message || "błąd połączenia"), true);
      return null;
    } finally {
      rtcStatusLoading = false;
    }
  }

  async function saveTimeInterval(input, command, minimum, maximum) {
    const value = Number(input.value);
    if (!Number.isInteger(value) || value < minimum || value > maximum) {
      setRtcFeedback("Podaj liczbę z dozwolonego zakresu.", true);
      loadTimeStatus();
      return;
    }
    if (!send(command, value)) {
      setRtcFeedback("Brak połączenia z urządzeniem.", true);
      return;
    }
    setRtcFeedback("Oczekiwanie na potwierdzenie urządzenia…");
    await new Promise(resolve => setTimeout(resolve, 500));
    const status = await loadTimeStatus();
    if (status && status[command === "timeint" ? "timeSyncInterval" : "timeSyncIntervalRTC"] === value)
      setRtcFeedback("Ustawienie zapisane.");
    else setRtcFeedback("Nie potwierdzono zapisu. Sprawdź połączenie.", true);
  }

  async function syncTimeNow() {
    if (rtcSyncing) return;
    rtcSyncing = true;
    rtcSyncNow.disabled = true;
    setRtcFeedback("Oczekiwanie na synchronizację NTP…");
    try {
      const response = await fetch("/api/time/sync", { method: "POST", cache: "no-store" });
      const result = await response.json();
      if (!response.ok || result.ok !== true) throw new Error(result.error || ("HTTP " + response.status));
      for (let attempt = 0; attempt < 15; attempt++) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        const status = await loadTimeStatus();
        if (status && status.syncCount > result.syncCount) {
          setRtcFeedback(status.rtcFound ? "Ręczna synchronizacja NTP zakończona; czas przekazano do RTC." : "Ręczna synchronizacja NTP zakończona; RTC nie został wykryty.");
          return;
        }
      }
      setRtcFeedback("Brak potwierdzenia synchronizacji NTP. Sprawdź połączenie i spróbuj ponownie.", true);
    } catch (error) {
      setRtcFeedback("Nie udało się rozpocząć synchronizacji: " + (error.message || "błąd połączenia"), true);
    } finally {
      rtcSyncing = false;
      rtcSyncNow.disabled = false;
      loadTimeStatus();
    }
  }

  function mqttRootMode() {
    const selected = mqttForm.querySelector('input[name="mqtt-root-mode"]:checked');
    return selected ? selected.value : "auto";
  }

  function renderMqttRoot() {
    const custom = mqttRootMode() === "custom";
    mqttCustomRootWrap.hidden = !custom;
    mqttRootModeLabel.textContent = custom ? "Własny" : "Automatyczny";
    mqttEffectiveRoot.textContent = mqttEffectiveRootValue || "—";
    mqttTopicList.textContent = mqttEffectiveRootValue ? ["command", "status", "volume", "playlist"].map(suffix => mqttEffectiveRootValue + "/" + suffix).join(" · ") : "—";
    renderHaYaml();
  }

  function renderHaYaml() {
    const name = haName.value.trim() || "VoxOne";
    const escapedName = name.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/[\r\n]/g, " ");
    const root = mqttEffectiveRootValue || "—";
    haYaml.textContent = "media_player:\n  - platform: yoradio\n    name: \"" + escapedName + "\"\n    root_topic: " + root;
    haCopy.disabled = !mqttEffectiveRootValue;
  }

  function setMqttFeedback(message, isError) {
    mqttFeedback.textContent = message;
    mqttFeedback.dataset.kind = isError ? "error" : "success";
  }

  function updateMqttFormState() {
    mqttFields.classList.toggle("is-disabled", !mqttEnabled.checked);
    mqttPasswordState.textContent = mqttPasswordSet ? "Hasło zapisane. Puste pole zachowuje obecne hasło." : "";
    mqttSave.disabled = mqttSaving;
  }

  async function loadMqttConfig() {
    try {
      const response = await fetch("/api/mqtt", { cache: "no-store" });
      const config = await response.json();
      if (!response.ok) throw new Error(config.error || ("HTTP " + response.status));
      mqttEnabled.checked = config.enabled === true;
      mqttHost.value = typeof config.host === "string" ? config.host : "";
      mqttPort.value = String(config.port || 1883);
      mqttUsername.value = typeof config.username === "string" ? config.username : "";
      mqttPassword.value = "";
      mqttPasswordSet = config.passwordSet === true;
      mqttClearPassword.checked = false;
      const custom = typeof config.rootTopic === "string" && config.rootTopic.length > 0;
      mqttForm.querySelector('input[name="mqtt-root-mode"][value="' + (custom ? "custom" : "auto") + '"]').checked = true;
      mqttRootTopic.value = custom ? config.rootTopic : "";
      mqttEffectiveRootValue = typeof config.effectiveRoot === "string" ? config.effectiveRoot : "";
      mqttConfigLoaded = true;
      setMqttFeedback("", false);
      renderMqttRoot();
      updateMqttFormState();
    } catch (error) {
      setMqttFeedback("Nie udało się pobrać konfiguracji MQTT: " + (error.message || "błąd połączenia"), true);
    }
  }

  async function saveMqttConfig(event) {
    event.preventDefault();
    if (mqttSaving) return;
    const body = new URLSearchParams();
    body.set("enabled", mqttEnabled.checked ? "true" : "false");
    body.set("host", mqttHost.value);
    body.set("port", mqttPort.value);
    body.set("username", mqttUsername.value);
    body.set("rootTopic", mqttRootMode() === "custom" ? mqttRootTopic.value : "");
    if (mqttPassword.value) body.set("password", mqttPassword.value);
    else if (mqttClearPassword.checked) body.set("clearPassword", "true");
    mqttSaving = true;
    updateMqttFormState();
    setMqttFeedback("Zapisywanie konfiguracji…", false);
    try {
      const response = await fetch("/api/mqtt", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" }, body: body.toString(), cache: "no-store" });
      const result = await response.json();
      if (!response.ok || result.ok !== true) throw new Error(result.error || ("HTTP " + response.status));
      mqttPassword.value = "";
      setMqttFeedback("Konfiguracja zapisana. VoxOne uruchomi się ponownie.", false);
    } catch (error) {
      setMqttFeedback("Nie zapisano konfiguracji MQTT: " + (error.message || "błąd połączenia"), true);
    } finally {
      mqttSaving = false;
      updateMqttFormState();
    }
  }

  function setHardwareFeedback(message, isError = false) {
    hardwareFeedback.textContent = message;
    hardwareFeedback.dataset.kind = isError ? "error" : "status";
  }

  function hardwareDirty() {
    return !!savedHardwareConfig && hardwareSelectionSaveable() &&
      (hardwareDisplay.value !== savedHardwareConfig.display ||
       hardwareInput.value !== savedHardwareConfig.input);
  }

  function hardwareSelectionSaveable() {
    return [hardwareDisplay, hardwareInput].every(select =>
      select.selectedOptions.length === 1 && !select.selectedOptions[0].disabled);
  }

  function renderHardwareFormState() {
    const dirty = hardwareDirty();
    hardwareDirtyBadge.hidden = !dirty;
    hardwareDisplay.disabled = !hardwareConfigLoaded || hardwareSaving;
    hardwareInput.disabled = !hardwareConfigLoaded || hardwareSaving;
    hardwareSaveRestart.disabled = hardwareSaving || !hardwareConfigLoaded || !dirty ||
      !hardwareSelectionSaveable();
  }

  const hardwareInputLabels = { none: "Brak", ec11: "Enkoder", buttons3: "Przyciski" };

  function replaceHardwareOptions(select, supported, selected, labels = {}) {
    select.replaceChildren();
    for (const item of supported) {
      const option = document.createElement("option");
      option.value = item.value;
      option.textContent = labels[item.value] || item.label;
      select.append(option);
    }
    select.value = selected;
  }

  function renderHardwareAudio(items) {
    const current = items.find(item => item.current === true);
    if (!current) throw new Error("Brak aktualnego układu audio w profilu sprzętu");
    hardwareAudio.replaceChildren();
    const option = document.createElement("option");
    option.value = current.value;
    option.textContent = current.label;
    hardwareAudio.append(option);
    hardwareAudio.value = current.value;
  }

  async function loadHardwareConfig() {
    try {
      const response = await fetch("/api/hardware", { cache: "no-store" });
      const snapshot = await response.json();
      if (!response.ok || !snapshot.config || !Array.isArray(snapshot.supportedDisplays) ||
          !Array.isArray(snapshot.supportedInputs) || !snapshot.roadmap ||
          !Array.isArray(snapshot.roadmap.audio))
        throw new Error(snapshot.error || ("HTTP " + response.status));
      replaceHardwareOptions(hardwareDisplay, snapshot.supportedDisplays,
        snapshot.config.display);
      replaceHardwareOptions(hardwareInput, snapshot.supportedInputs,
        snapshot.config.input, hardwareInputLabels);
      if (!hardwareDisplay.value || !hardwareInput.value)
        throw new Error("Urządzenie zwróciło niezgodną konfigurację");
      savedHardwareConfig = {
        display: snapshot.config.display,
        input: snapshot.config.input
      };
      text("hardware-family", snapshot.family || "—");
      text("hardware-mcu", snapshot.mcu || "—");
      renderHardwareAudio(snapshot.roadmap.audio);
      hardwareConfigLoaded = true;
      setHardwareFeedback("");
    } catch (error) {
      hardwareConfigLoaded = false;
      savedHardwareConfig = null;
      setHardwareFeedback("Nie udało się pobrać konfiguracji sprzętu: " +
        (error.message || "błąd połączenia"), true);
    }
    renderHardwareFormState();
  }

  function hardwareSaveError(error) {
    if (error === "unsupported_hardware")
      return "Wybrana konfiguracja nie jest obsługiwana przez tę rodzinę sprzętu.";
    if (error === "invalid_value" || error === "missing_field")
      return "Urządzenie odrzuciło nieprawidłową konfigurację sprzętu.";
    if (error === "storage_failed")
      return "Nie udało się zapisać konfiguracji w pamięci urządzenia.";
    if (error === "reboot_pending") return "Restart urządzenia jest już w toku.";
    return error || "błąd połączenia";
  }

  async function restartAfterHardwareSave() {
    hardwareSaving = true;
    renderHardwareFormState();
    setHardwareFeedback("Restartowanie urządzenia...");
    if (!send("reboot", 1)) {
      hardwareSaving = false;
      renderHardwareFormState();
      setHardwareFeedback("Konfiguracja została zapisana, ale brak połączenia potrzebnego do restartu.", true);
      return;
    }
    await waitForDeviceRestart({
      delay: 1200,
      onReturn: () => location.replace("/voxone.html?restarted=" + Date.now() + "#hardware"),
      onTimeout: () => {
        hardwareSaving = false;
        renderHardwareFormState();
        setHardwareFeedback("Konfiguracja została zapisana, ale nie udało się ponownie połączyć z VoxOne.", true);
      }
    });
  }

  async function saveHardwareConfig(restart) {
    if (hardwareSaving || !hardwareConfigLoaded) return;
    if (!hardwareDirty() || !hardwareSelectionSaveable()) return;
    hardwareSaving = true;
    renderHardwareFormState();
    setHardwareFeedback("Zapisywanie konfiguracji sprzętu…");
    const body = new URLSearchParams();
    body.set("display", hardwareDisplay.value);
    body.set("input", hardwareInput.value);
    try {
      const response = await fetch("/api/hardware", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
        body: body.toString(), cache: "no-store"
      });
      const result = await response.json();
      if (!response.ok || result.ok !== true || result.restartRequired !== true || !result.config)
        throw new Error(hardwareSaveError(result.error || ("HTTP " + response.status)));
      savedHardwareConfig = { display: result.config.display, input: result.config.input };
      hardwareDisplay.value = result.config.display;
      hardwareInput.value = result.config.input;
      setHardwareFeedback("Konfiguracja sprzętu została zapisana. Uruchom ponownie VoxOne, aby zastosować zmiany.");
    } catch (error) {
      setHardwareFeedback("Nie zapisano konfiguracji sprzętu: " +
        (error.message || "błąd połączenia"), true);
      return;
    } finally {
      hardwareSaving = false;
      renderHardwareFormState();
    }
    if (restart) await restartAfterHardwareSave();
  }

  async function copyHaYaml() {
    const value = haYaml.textContent;
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(value);
      else {
        const temporary = document.createElement("textarea");
        temporary.value = value;
        temporary.setAttribute("readonly", "");
        temporary.style.position = "fixed";
        temporary.style.opacity = "0";
        document.body.appendChild(temporary);
        temporary.select();
        const copied = document.execCommand("copy");
        temporary.remove();
        if (!copied) throw new Error("clipboard unavailable");
      }
      haCopyStatus.textContent = "Skopiowano";
    } catch (_) {
      haCopyStatus.textContent = "Nie udało się skopiować";
    }
    setTimeout(() => { haCopyStatus.textContent = ""; }, 2200);
  }

  function renderConnection() {
    const badge = document.getElementById("ws-state");
    badge.dataset.state = state.connection;
    badge.textContent = {
      connected: "Połączono",
      connecting: "Łączenie...",
      disconnected: "Rozłączono"
    }[state.connection];
    const connected = state.connection === "connected";
    renderSourceSelector();
    const btDisconnected = state.webStatus?.source === "BT" && !state.webStatus.btConnected;
    buttons.prev.disabled = !connected || !state.webStatus || btDisconnected;
    buttons.next.disabled = !connected || !state.webStatus || btDisconnected;
    buttons.play.disabled = !connected || !state.webStatus || btDisconnected ||
      !state.webStatus.playback;
    for (const slider of volumeSliders) slider.disabled = !connected || state.volume100 === null;
    for (const button of muteButtons) button.disabled = !connected || state.muted === null;
    maximumVolumeSlider.disabled = !connected || state.maximumVolume === null;
    startupModeSelect.disabled = !connected || state.startupMode === null;
    startupFixedSlider.disabled = !connected || state.startupMode !== 1 || state.startupFixedVolume === null;
    brightnessSlider.disabled = !connected || !state.canBrightness || state.brightness === null;
    for (const [key, control] of Object.entries(audioControls)) {
      control.slider.disabled = !connected || state[key] === null;
    }
    for (const button of tonePresetButtons) {
      button.disabled = !connected || state.bass === null || state.middle === null || state.treble === null;
    }
    stationList.querySelectorAll(".station-play").forEach(button => {
      button.disabled = !connected;
    });
    renderStationActions();
    renderDisplaySettings();
    renderFooter();
    renderNetworkInfo();
    advancedAudio.syncShared();
  }

  function renderStation() {
    const status = state.webStatus;
    text("status-name-label", status?.source === "BT" ? "URZĄDZENIE" : "STACJA");
    text("current-station-name", status?.name || "—");
  }

  function renderMetadata() {
    const status = state.webStatus;
    const bt = status?.source === "BT";
    document.getElementById("metadata").hidden = bt;
    document.getElementById("metadata-hint").hidden = bt;
    document.getElementById("bt-metadata").hidden = !bt || !status.btConnected;
    document.getElementById("bt-disconnected").hidden = !bt || status.btConnected;
    text("metadata", status?.metadata || "—");
    text("bt-artist", bt && status.btConnected && status.artist ? status.artist : "—");
    text("bt-title", bt && status.btConnected && status.title ? status.title : "—");
  }

  function renderStream() {
    const status = state.webStatus;
    if (status?.source === "BT") {
      const rate = status.btConnected ? status.sampleRate : 0;
      text("codec", rate > 0 ? (Number.isInteger(rate / 1000) ? rate / 1000 : (rate / 1000).toFixed(1)) + " kHz" : "—");
      return;
    }
    const parts = [];
    const codec = status?.codec;
    const bitrate = status?.bitrate;
    if (codec) parts.push(codec);
    if (bitrate > 0) parts.push(String(bitrate));
    text("codec", parts.length ? parts.join(" ") : "—");
  }

  function renderSource() {
    text("source", state.webStatus?.activeSource?.toUpperCase() || "—");
  }

  function renderSourceSelector() {
    const status = state.webStatus;
    const sources = Array.isArray(status?.availableSources) ? status.availableSources : [];
    const ids = sources.filter(source => typeof source === "string");
    const key = ids.join(",");
    if (sourceSelector.dataset.sources !== key) {
      sourceSelector.replaceChildren(...ids.map(source => {
        const button = document.createElement("button");
        button.type = "button";
        button.dataset.source = source;
        button.textContent = source.toUpperCase();
        return button;
      }));
      sourceSelector.dataset.sources = key;
    }
    const active = status?.activeSource;
    for (const button of sourceSelector.querySelectorAll("button")) {
      const source = button.dataset.source;
      const offline = source === "bt" && status?.btModule?.online !== true;
      button.textContent = offline ? "BT · offline" : source.toUpperCase();
      button.setAttribute("aria-pressed", source === active ? "true" : "false");
      button.disabled = state.connection !== "connected" || !status ||
        source === active || offline;
    }
  }

  function renderRssi() {
    text("rssi", state.rssi === null ? "—" : state.rssi + " dBm");
  }

  function renderPlaying() {
    const status = state.webStatus;
    const playback = status?.playback || "";
    const bt = status?.source === "BT";
    buttons.play.textContent = !playback ? "—" : playback === "PLAY" ? (bt ? "❚❚" : "■") : "▶";
    buttons.play.setAttribute("aria-label", !playback ? "Stan odtwarzania niedostępny" :
      playback === "PLAY" ? (bt ? "Pauza" : "Zatrzymaj") : "Odtwarzaj");
    text("playback-state", bt && !status.btConnected ? "Brak połączenia" : playback || "—");
    renderConnection();
  }

  function renderStatus() {
    renderStation();
    renderMetadata();
    renderStream();
    renderSource();
    renderPlaying();
  }

  function showVolume(value) {
    text("volume", value === null ? "—" : String(value));
    text("audio-volume", value === null ? "—" : String(value));
    if (value !== null) {
      for (const slider of volumeSliders) {
        if (draggingVolume && slider === activeVolumeSlider) continue;
        slider.value = String(value);
      }
    }
    renderConnection();
  }

  function renderVolume() {
    showVolume(state.volume100);
    for (const button of muteButtons) button.setAttribute("aria-pressed", state.muted === true ? "true" : "false");
  }

  function renderVolumeSettings() {
    const maxShown = volumeSettingEditing.maximumVolume ?? state.maximumVolume;
    if (!volumeSettingDragging.maximumVolume && maxShown !== null) maximumVolumeSlider.value = String(maxShown);
    maximumVolumeValue.textContent = maxShown === null ? "—" : String(maxShown);
    if (state.startupMode !== null && volumeSettingEditing.startupMode === null) {
      startupModeSelect.value = String(state.startupMode);
    }
    startupFixedControl.hidden = state.startupMode !== 1;
    const fixedShown = volumeSettingEditing.startupFixedVolume ?? state.startupFixedVolume;
    if (!volumeSettingDragging.startupFixedVolume && fixedShown !== null) startupFixedSlider.value = String(fixedShown);
    startupFixedValue.textContent = fixedShown === null ? "—" : String(fixedShown);
    const pending = Object.values(volumeSettingEditing).some(value => value !== null);
    volumeSettingsPending.hidden = !pending;
    renderConnection();
  }

  function renderDisplaySettings() {
    displaySettingsCard.hidden = !state.canFlip && !state.canVu && !state.canBrightness &&
      !state.canScrollSettings;
    flipScreenControl.hidden = !state.canFlip;
    flipScreenToggle.disabled = state.connection !== "connected" ||
      !state.canFlip || state.flip === null || flipPending;
    if (!flipPending && state.flip !== null) flipScreenToggle.checked = state.flip;
    vuMeterControl.hidden = !state.canVu;
    vuMeterToggle.disabled = state.connection !== "connected" ||
      !state.canVu || state.vu === null || vuAwaiting !== null;
    if (vuAwaiting === null && state.vu !== null) vuMeterToggle.checked = state.vu;
    vuMeterValue.textContent = vuAwaiting !== null ? "Zapisywanie…" :
      state.vu === null ? "—" : state.vu ? "ON" : "OFF";
    brightnessControl.hidden = !state.canBrightness;
    brightnessUnavailable.hidden = state.canBrightness;
    brightnessSlider.disabled = state.connection !== "connected" ||
      !state.canBrightness || state.brightness === null;
    const brightnessShown = brightnessDragging && brightnessPending !== null
      ? brightnessPending : brightnessAwaiting !== null ? brightnessAwaiting : state.brightness;
    if (!brightnessDragging && brightnessAwaiting === null && state.brightness !== null) {
      brightnessSlider.value = String(state.brightness);
    } else if (brightnessDragging && brightnessPending !== null) {
      brightnessSlider.value = String(brightnessPending);
    }
    brightnessValue.textContent = brightnessShown === null ? "—" : brightnessShown + "%";
    autoReturnControl.hidden = !state.canFlip;
    stationListTimeoutInput.disabled = state.connection !== "connected" ||
      !state.canFlip || state.stationListTimeout === null;
    btTimeoutControl.hidden = !state.canBtTransport;
    btTransportTimeoutInput.disabled = state.connection !== "connected" ||
      !state.canBtTransport || state.btTransportTimeout === null;
    if (document.activeElement !== stationListTimeoutInput && state.stationListTimeout !== null)
      stationListTimeoutInput.value = String(state.stationListTimeout);
    if (document.activeElement !== btTransportTimeoutInput && state.btTransportTimeout !== null)
      btTransportTimeoutInput.value = String(state.btTransportTimeout);
    scrollSettingsForm.hidden = !state.canScrollSettings;
    const scrollReady = state.scrollEnabled !== null && state.scrollSpeed !== null &&
      state.scrollPauseMs !== null;
    for (const control of [scrollEnabledSelect, scrollPauseSelect, scrollSpeedSelect]) {
      control.disabled = state.connection !== "connected" || !state.canScrollSettings ||
        !state.scrollCoreActive || !scrollReady || scrollSettingsSaving;
    }
    if (scrollReady && !scrollSettingsDirty && !scrollSettingsSaving) {
      scrollEnabledSelect.value = String(state.scrollEnabled);
      scrollPauseSelect.value = String(state.scrollPauseMs);
      scrollSpeedSelect.value = state.scrollSpeed;
    }
    scrollSettingsSave.disabled = state.connection !== "connected" ||
      !state.canScrollSettings || !state.scrollCoreActive || !scrollReady ||
      !scrollSettingsDirty || scrollSettingsSaving;
    scrollSettingsStatus.dataset.kind = scrollSettingsFeedbackError ? "error" : "notice";
    scrollSettingsStatus.textContent = scrollSettingsSaving ? "Zapisywanie i weryfikacja…" :
      scrollSettingsFeedback || (scrollSettingsDirty ? "Niezapisane zmiany." :
      (state.canScrollSettings ? (state.scrollCoreActive
        ? "Ustawienia są aktywnie stosowane przez wyświetlacz."
        : "Przewijanie automatyczne działa według ustawień renderera. Regulacja przez WWW wymaga aktywacji wspólnego silnika CORE.") : ""));
    scrollSettingsSource.textContent = !state.canScrollSettings ? "" :
      "Źródło: " + (state.scrollSettingsSource === "userSettings"
        ? "ustawienia użytkownika" : "wartości domyślne renderera") + ".";
    flipScreenFeedback.hidden = !state.canFlip;
    flipScreenFeedback.textContent = flipPending
      ? "Oczekiwanie na potwierdzenie urządzenia…"
      : "Zmiana działa od razu, bez restartu.";
  }

  function confirmVolumeSetting(key, value) {
    state[key] = value;
    if (volumeSettingEditing[key] !== null) {
      clearTimeout(volumeSettingTimers[key]);
      volumeSettingEditing[key] = null;
    }
    renderVolumeSettings();
  }

  function sendVolumeSetting(key, command, value) {
    if (!send(command, value)) {
      volumeSettingEditing[key] = null;
      renderVolumeSettings();
      return;
    }
    volumeSettingEditing[key] = value;
    clearTimeout(volumeSettingTimers[key]);
    volumeSettingTimers[key] = setTimeout(() => {
      volumeSettingEditing[key] = null;
      renderVolumeSettings();
    }, 2000);
    renderVolumeSettings();
  }

  function signedValue(value) {
    if (value === null) return "—";
    return (value > 0 ? "+" : "") + value;
  }

  function renderAudio() {
    text("audio-bass", signedValue(state.bass));
    text("audio-middle", signedValue(state.middle));
    text("audio-treble", signedValue(state.treble));
    text("audio-balance", signedValue(state.balance));
    text("audio-balance-note", state.balance === null ? "" : state.balance < 0 ? "lewo" : state.balance > 0 ? "prawo" : "środek");
    for (const [key, control] of Object.entries(audioControls)) {
      if (state[key] !== null && !control.dragging) control.slider.value = String(state[key]);
    }
    const hasTone = state.bass !== null && state.middle !== null && state.treble !== null;
    const activePreset = hasTone ? Object.keys(tonePresets).find(name => {
      const [bass, middle, treble] = tonePresets[name];
      return state.bass === bass && state.middle === middle && state.treble === treble;
    }) : null;
    for (const button of tonePresetButtons) {
      button.setAttribute("aria-pressed", String(button.dataset.tonePreset === activePreset));
    }
    tonePresetUser.classList.toggle("is-active", hasTone && !activePreset);
    renderConnection();
  }

  function renderIdentity() {
    const version = state.version ? state.version + (state.channel ? "-" + state.channel : "") : "—";
    const profile = state.profile ? state.profile.toUpperCase() : "—";
    text("header-version", "Wersja " + version);
    text("header-profile", "Profil " + profile);
    text("system-version", "VoxOne " + version);
    text("system-build", state.build || "—");
    text("system-profile", profile);
    text("update-version", "VoxOne " + version);
    text("update-build", state.build || "—");
    text("update-profile", profile);
    text("system-base", "yoRadio " + (state.baseVersion || "—"));
  }

  function updateCurrentMarker(previous) {
    for (const number of [previous, state.current]) {
      if (!Number.isInteger(number)) continue;
      const row = stationList.querySelector('[data-station="' + number + '"]');
      if (!row) continue;
      const active = number === state.current;
      row.classList.toggle("is-current", active);
      row.querySelector(".station-playing").hidden = !active;
      if (active) row.setAttribute("aria-current", "true");
      else row.removeAttribute("aria-current");
    }
  }

  function stationCountLabel(count) {
    if (count === 1) return "1 stacja";
    if (count % 10 >= 2 && count % 10 <= 4 && (count % 100 < 12 || count % 100 > 14)) {
      return count + " stacje";
    }
    return count + " stacji";
  }

  function renderStationFeedback() {
    stationFeedback.textContent = state.error || state.notice;
    stationFeedback.dataset.kind = state.error ? "error" : "notice";
    stationFormError.textContent = stationDialog.open ? state.error : "";
  }

  function setStationFeedback(message, isError = false) {
    state.error = isError ? message : "";
    state.notice = isError ? "" : message;
    renderStationFeedback();
  }

  function renderStationActions() {
    const locked = state.loading || state.mutationInProgress ||
      stationImportDialog.open || state.stationsStatus !== "ready" || !state.revision;
    stationAdd.disabled = locked;
    stationImport.disabled = locked;
    const exportLocked = state.loading || state.mutationInProgress || stationImportDialog.open;
    stationExport.setAttribute("aria-disabled", String(exportLocked));
    stationExport.tabIndex = exportLocked ? -1 : 0;
    stationRetry.disabled = state.loading || state.mutationInProgress;
    stationSaving.hidden = !state.mutationInProgress;
    stationSaving.textContent = state.importing ? "Importowanie..." : "Zapisywanie…";
    stationList.querySelectorAll(".station-mutate").forEach(button => {
      button.disabled = locked || button.dataset.boundary === "true";
    });
    for (const input of [stationName, stationUrl, stationOvol, stationCancel, stationSave]) {
      input.disabled = state.mutationInProgress;
    }
  }

  function stationAction(action, label, ariaLabel, number, boundary = false) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "station-action station-mutate";
    button.dataset.action = action;
    button.dataset.number = String(number);
    if (boundary) button.dataset.boundary = "true";
    button.textContent = label;
    button.setAttribute("aria-label", ariaLabel);
    if (action === "up" || action === "down") button.title = ariaLabel;
    button.disabled = boundary || state.loading || state.mutationInProgress;
    return button;
  }

  function renderStationList() {
    const query = state.stationQuery.trim().toLocaleLowerCase("pl");
    const visible = state.stations.filter(station =>
      station.name.toLocaleLowerCase("pl").includes(query) ||
      station.url.toLocaleLowerCase("pl").includes(query)
    );
    const fragment = document.createDocumentFragment();
    for (const station of visible) {
      const active = station.number === state.current;
      const row = document.createElement("li");
      row.className = "station-row";
      row.dataset.station = String(station.number);
      if (active) {
        row.classList.add("is-current");
        row.setAttribute("aria-current", "true");
      }

      const number = document.createElement("span");
      number.className = "station-number";
      number.textContent = String(station.number);

      const main = document.createElement("div");
      main.className = "station-main";
      const title = document.createElement("div");
      title.className = "station-title";
      const name = document.createElement("strong");
      name.textContent = station.name;
      name.title = station.name;
      const badge = document.createElement("span");
      badge.className = "station-playing";
      badge.textContent = "GRA";
      badge.hidden = !active;
      title.append(name, badge);
      const url = document.createElement("span");
      url.className = "station-url";
      url.textContent = station.url;
      url.title = station.url;
      main.append(title, url);

      const ovol = document.createElement("span");
      ovol.className = "station-ovol";
      ovol.textContent = (station.ovol > 0 ? "+" : "") + station.ovol;

      const actions = document.createElement("div");
      actions.className = "station-actions";
      const play = document.createElement("button");
      play.type = "button";
      play.className = "station-play";
      play.dataset.number = String(station.number);
      play.textContent = "GRAJ";
      play.setAttribute("aria-label", "Graj: " + station.name);
      play.disabled = state.connection !== "connected";
      actions.append(
        play,
        (() => {
          const toggle = stationAction("metadata", "A↔T", "Zamień artystę i utwór: " + station.name, station.number);
          toggle.title = "Zamień artystę i utwór";
          toggle.classList.toggle("is-on", station.swapArtistTitle);
          toggle.setAttribute("aria-pressed", String(station.swapArtistTitle));
          if (state.pendingMetadataNumber === station.number) toggle.textContent = "…";
          return toggle;
        })(),
        stationAction("edit", "Edytuj", "Edytuj: " + station.name, station.number),
        stationAction("delete", "Usuń", "Usuń: " + station.name, station.number),
        stationAction("up", "↑", "Przesuń w górę: " + station.name, station.number, station.number === 1),
        stationAction("down", "↓", "Przesuń w dół: " + station.name, station.number, station.number === state.count)
      );
      row.append(number, main, ovol, actions);
      fragment.append(row);
    }
    stationList.replaceChildren(fragment);
    text("stations-count", query ? visible.length + " z " + state.count : stationCountLabel(state.count));
    document.querySelector(".station-list-heading").hidden = state.count === 0;
    text("stations-message", state.count === 0 ? "Brak zapisanych stacji." :
      visible.length === 0 ? "Brak stacji pasujących do wyszukiwania." : "");
    renderStationActions();
  }

  async function loadStations() {
    if (state.loading) return false;
    state.loading = true;
    state.stationsStatus = "loading";
    const currentSequence = wsCurrentSequence;
    text("stations-count", "Ładowanie...");
    text("stations-message", "Pobieranie listy stacji...");
    stationRetry.hidden = true;
    renderStationActions();
    try {
      const response = await fetch("/api/stations", { cache: "no-store" });
      if (!response.ok) throw new Error("HTTP " + response.status);
      const data = await response.json();
      if (!data || !Array.isArray(data.stations) || !Number.isInteger(data.count) ||
          data.count !== data.stations.length || !Number.isInteger(data.current) ||
          data.current < 0 || data.current > data.count ||
          typeof data.revision !== "string" || !/^[0-9a-f]{8}$/i.test(data.revision) ||
          !data.stations.every((station, index) =>
            station.number === index + 1 && typeof station.name === "string" &&
            typeof station.id === "string" && /^[0-9A-F]{16}$/.test(station.id) &&
            typeof station.url === "string" && Number.isInteger(station.ovol) &&
            (station.metadataMode === "normal" || station.metadataMode === "swap") &&
            typeof station.swapArtistTitle === "boolean" &&
            station.swapArtistTitle === (station.metadataMode === "swap"))) {
        throw new Error("Niepoprawna odpowiedź listy stacji");
      }
      state.stations = data.stations;
      state.count = data.count;
      state.revision = data.revision;
      state.stationsStatus = "ready";
      state.error = "";
      state.notice = "";
      if (wsCurrentSequence === currentSequence) state.current = data.current;
      renderStationFeedback();
      renderStationList();
      return true;
    } catch (error) {
      console.warn("VoxOne: stations fetch failed", error);
      state.stationsStatus = "error";
      state.revision = null;
      state.error = "Nie udało się pobrać listy stacji.";
      state.notice = "";
      renderStationFeedback();
      text("stations-count", "Stacje niedostępne");
      text("stations-message", "Nie udało się pobrać listy stacji.");
      stationRetry.hidden = false;
      return false;
    } finally {
      state.loading = false;
      renderStationActions();
    }
  }

  function utf8Length(value) {
    if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(value).length;
    return new Blob([value]).size;
  }

  function validateStationForm() {
    const name = stationName.value.trim();
    const url = stationUrl.value.trim();
    const ovolText = stationOvol.value.trim();
    if (!name) return { error: "Podaj nazwę stacji." };
    if (utf8Length(name) > 169) return { error: "Nazwa może mieć najwyżej 169 bajtów UTF-8." };
    if (!url) return { error: "Podaj URL stacji." };
    if (utf8Length(url) > 169) return { error: "URL może mieć najwyżej 169 bajtów." };
    if (!/^[+-]?\d+$/.test(ovolText) || !Number.isInteger(Number(ovolText)) ||
        Number(ovolText) < -30 || Number(ovolText) > 30) {
      return { error: "OVOL musi być liczbą całkowitą od −30 do 30." };
    }
    return { name, url, ovol: String(Number(ovolText)) };
  }

  function showStationView(directory) {
    myStationsView.hidden = directory;
    directoryView.hidden = !directory;
    myStationsTab.setAttribute("aria-selected", String(!directory));
    directoryTab.setAttribute("aria-selected", String(directory));
    if (directory) directoryQuery.focus();
  }

  function directoryMessage(message, error = false) {
    directoryStatus.textContent = message;
    directoryStatus.dataset.kind = error ? "error" : "notice";
  }

  function directoryError(status, code, phase) {
    if (code === "offline") return "VoxOne nie ma połączenia z internetem.";
    if (code === "insufficient_memory") return "Brak pamięci na wyszukiwanie. Spróbuj później.";
    if (code === "upstream_response_too_large") return "Katalog zwrócił zbyt dużą odpowiedź.";
    if (code === "upstream_invalid_json") return "Katalog zwrócił nieprawidłowe dane.";
    if (status === 504) return "Upłynął czas oczekiwania na katalog.";
    if (status === 429) return "Trwa inne wyszukiwanie. Spróbuj za chwilę.";
    if (status === 400 && phase === "start") return "Sprawdź nazwę stacji i kraj.";
    if (code === "bad_job") return "Nieprawidłowy identyfikator wyszukiwania.";
    if (status === 404 && phase === "poll") return "Wynik wyszukiwania nie jest już dostępny.";
    return "Nie udało się pobrać katalogu stacji.";
  }

  function renderDirectoryResults() {
    const fragment = document.createDocumentFragment();
    directoryStations.forEach((station, index) => {
      const row = document.createElement("li");
      row.className = "directory-result";
      const details = document.createElement("div");
      details.className = "directory-result-main";
      const name = document.createElement("strong");
      name.textContent = station.name;
      const meta = document.createElement("span");
      const country = station.countryCode === "PL" ? "Polska" :
        (station.country || station.countryCode || "Kraj nieznany");
      const fields = [country];
      if (station.codec) fields.push(station.codec);
      fields.push(station.bitrate > 0 ? station.bitrate + " kbps" : "bitrate nieznany");
      meta.textContent = fields.join(" · ");
      details.append(name, meta);
      const add = document.createElement("button");
      add.type = "button";
      add.textContent = "Dodaj";
      add.dataset.directoryIndex = String(index);
      row.append(details, add);
      fragment.append(row);
    });
    directoryResults.replaceChildren(fragment);
  }

  async function searchDirectory() {
    if (directoryBusy) return;
    const query = directoryQuery.value.trim();
    if (!query || utf8Length(query) > 80) {
      directoryMessage("Podaj nazwę stacji (najwyżej 80 bajtów).", true);
      return;
    }
    directoryBusy = true;
    directorySearchButton.disabled = true;
    directoryResults.replaceChildren();
    directoryStations = [];
    directoryMessage("Wyszukiwanie stacji...");
    let phase = "start";
    try {
      const parameters = new URLSearchParams({
        q: query, country: directoryCountry.value, limit: "20"
      });
      let response = await fetch("/api/directory/search?" + parameters, { cache: "no-store" });
      let payload = await response.json().catch(() => null);
      if (response.status === 202) {
        if (!payload || !Number.isSafeInteger(payload.job) || payload.job <= 0)
          throw { status: 502, code: "invalid_job_response" };
        const jobId = payload.job;
        phase = "poll";
        let done = false;
        for (let attempt = 0; attempt < 80; attempt++) {
          await new Promise(resolve => setTimeout(resolve, 250));
          response = await fetch("/api/directory/search?job=" + jobId, { cache: "no-store" });
          payload = await response.json().catch(() => null);
          if (response.status === 202) {
            if (!payload || payload.status !== "pending")
              throw { status: 502, code: "invalid_pending_response" };
            continue;
          }
          done = true;
          break;
        }
        if (!done) throw { status: 504 };
      }
      if (!response.ok) throw { status: response.status, code: payload && payload.error };
      if (!payload || !Array.isArray(payload.results) || payload.results.length > 20 ||
          !payload.results.every(station => station && typeof station.name === "string" &&
            typeof station.url === "string" && typeof station.country === "string" &&
            typeof station.countryCode === "string" && typeof station.codec === "string" &&
            Number.isInteger(station.bitrate))) throw { status: 502 };
      directoryStations = payload.results;
      renderDirectoryResults();
      directoryMessage(directoryStations.length ?
        "Znaleziono " + directoryStations.length + " stacji." : "Nie znaleziono stacji.");
    } catch (error) {
      console.warn("VoxOne: directory search failed", error);
      directoryMessage(directoryError(error.status, error.code, phase), true);
    } finally {
      directoryBusy = false;
      directorySearchButton.disabled = false;
    }
  }
  function mutationErrorMessage(status) {
    return ({
      400: "Nieprawidłowe dane.",
      404: "Stacja już nie istnieje.",
      409: "Lista stacji została zmieniona w innym oknie.",
      422: "Nazwa, URL lub OVOL są nieprawidłowe.",
      507: "Brak miejsca na bezpieczny zapis playlisty.",
      500: "Nie udało się zapisać playlisty. Poprzednia lista została zachowana."
    })[status] || "Nie udało się zapisać zmiany. Sprawdź połączenie i spróbuj ponownie.";
  }

  async function mutateStation(route, fields, successMessage) {
    if (state.loading || state.mutationInProgress || state.stationsStatus !== "ready" ||
        !state.revision) return false;
    state.mutationInProgress = true;
    state.pendingMetadataNumber = route === "metadata" ?
      (state.stations.find(station => station.id === fields.id)?.number ?? null) : null;
    setStationFeedback("");
    if (state.pendingMetadataNumber !== null) renderStationList();
    renderStationActions();
    try {
      const body = new URLSearchParams({ revision: state.revision, ...fields });
      const response = await fetch("/api/stations/" + route, {
        method: "POST", body, cache: "no-store"
      });
      const result = await response.json().catch(() => null);
      if (response.status === 409 && result && result.error === "revision_conflict") {
        if (stationDialog.open) stationDialog.close();
        state.editorNumber = null;
        const refreshed = await loadStations();
        setStationFeedback(refreshed ?
          "Lista stacji została zmieniona w innym oknie. Odświeżono aktualne dane." :
          "Lista stacji została zmieniona w innym oknie. Nie udało się pobrać aktualnych danych.", !refreshed);
        return false;
      }
      if (!response.ok) throw { status: response.status, code: result && result.error };
      if (!result || result.ok !== true) throw { status: 500 };
      if (stationDialog.open) stationDialog.close();
      state.editorNumber = null;
      const refreshed = await loadStations();
      setStationFeedback(refreshed ? successMessage :
        "Zmiana została zapisana, ale nie udało się odświeżyć listy. Użyj przycisku Ponów.", !refreshed);
      return true;
    } catch (error) {
      console.warn("VoxOne: station mutation failed", error);
      setStationFeedback(mutationErrorMessage(error.status), true);
      return false;
    } finally {
      state.pendingMetadataNumber = null;
      state.mutationInProgress = false;
      if (state.stationsStatus === "ready") renderStationList();
      renderStationActions();
    }
  }

  function importErrorMessage(status) {
    return ({
      400: "Nieprawidłowe żądanie importu.",
      409: "Lista stacji została zmieniona w innym oknie.",
      413: "Plik playlisty jest zbyt duży.",
      422: "Plik playlisty ma nieprawidłowy format.",
      507: "Brak miejsca na bezpieczny zapis playlisty.",
      500: "Nie udało się zaimportować playlisty. Poprzednia lista została zachowana."
    })[status] || "Nie udało się zaimportować playlisty. Sprawdź połączenie i spróbuj ponownie.";
  }

  async function importPlaylist() {
    if (state.loading || state.mutationInProgress || state.stationsStatus !== "ready" ||
        !state.revision) return;
    const file = stationImportFile.files[0];
    if (!file) {
      stationImportDialog.close();
      return;
    }
    if (file.size > 192 * 1024) {
      stationImportDialog.close();
      setStationFeedback(importErrorMessage(413), true);
      return;
    }
    const revision = state.revision;
    state.mutationInProgress = true;
    state.importing = true;
    stationImportDialog.close();
    setStationFeedback("");
    renderStationActions();
    try {
      const body = new FormData();
      body.append("revision", revision);
      body.append("file", file, file.name);
      const response = await fetch("/api/stations/import", {
        method: "POST", body, cache: "no-store"
      });
      const result = await response.json().catch(() => null);
      if (response.status === 409) {
        const refreshed = await loadStations();
        setStationFeedback(refreshed ?
          "Lista stacji została zmieniona w innym oknie. Odświeżono aktualne dane. Wybierz plik ponownie, jeśli nadal chcesz go zaimportować." :
          "Lista stacji została zmieniona w innym oknie. Nie udało się pobrać aktualnych danych.", !refreshed);
        return;
      }
      if (!response.ok) throw { status: response.status };
      if (!result || result.ok !== true) throw { status: 500 };
      const refreshed = await loadStations();
      setStationFeedback(refreshed ? "Playlista została zaimportowana." :
        "Playlista została zaimportowana, ale nie udało się odświeżyć listy. Użyj przycisku Ponów.", !refreshed);
    } catch (error) {
      console.warn("VoxOne: playlist import failed", error);
      setStationFeedback(importErrorMessage(error.status), true);
    } finally {
      stationImportFile.value = "";
      state.importing = false;
      state.mutationInProgress = false;
      renderStationActions();
    }
  }

  function openStationForm(number = null) {
    if (state.loading || state.mutationInProgress || state.stationsStatus !== "ready") return;
    const station = number === null ? null : state.stations[number - 1];
    if (number !== null && (!station || station.number !== number)) return;
    state.editorNumber = number;
    stationForm.reset();
    text("station-dialog-title", station ? "Edytuj stację" : "Dodaj stację");
    stationName.value = station ? station.name : "";
    stationUrl.value = station ? station.url : "";
    stationOvol.value = station ? String(station.ovol) : "0";
    setStationFeedback("");
    stationDialog.showModal();
    stationName.focus();
  }
  function resetRuntime() {
    const previousCurrent = state.current;
    for (const key of ["source", "station", "metadata", "codec", "bitrate", "rssi", "volume", "volume100", "muted", "maximumVolume", "startupMode", "startupFixedVolume", "brightness", "stationListTimeout", "btTransportTimeout", "bass", "middle", "treble", "balance", "playing", "current", "ip"]) {
      state[key] = null;
    }
    state.webStatus = null;
    state.systemInfo = null;
    state.networkInfo = null;
    renderBtModule();
    renderSystemInfo();
    renderNetworkInfo();
    state.canBrightness = false;
    state.canBtTransport = false;
    state.flip = null;
    state.canFlip = false;
    state.vu = null;
    state.canVu = false;
    state.canScrollSettings = false;
    state.scrollEnabled = null;
    state.scrollSpeed = null;
    state.scrollPauseMs = null;
    state.scrollSettingsSource = null;
    state.scrollCoreActive = false;
    flipPending = false;
    clearTimeout(flipTimer);
    vuAwaiting = null;
    clearTimeout(vuTimer);
    clearTimeout(brightnessTimer);
    clearTimeout(brightnessAckTimer);
    brightnessDragging = false;
    brightnessPending = null;
    brightnessAwaiting = null;
    scrollSettingsSaving = false;
    scrollSettingsPending = null;
    scrollSettingsDirty = false;
    scrollSettingsFeedback = "";
    scrollSettingsFeedbackError = false;
    clearTimeout(scrollSettingsTimer);
    for (const key of Object.keys(volumeSettingEditing)) {
      volumeSettingEditing[key] = null;
      clearTimeout(volumeSettingTimers[key]);
    }
    volumeSettingDragging.maximumVolume = false;
    volumeSettingDragging.startupFixedVolume = false;
    draggingVolume = false;
    activeVolumeSlider = null;
    awaitingVolume = null;
    pendingVolume = null;
    clearTimeout(volumeTimer);
    clearTimeout(volumeAckTimer);
    renderStatus();
    renderRssi();
    renderVolume();
    renderVolumeSettings();
    renderDisplaySettings();
    for (const control of Object.values(audioControls)) {
      control.dragging = false;
      clearTimeout(control.ackTimer);
    }
    renderAudio();
    text("system-ip", "—");
    updateCurrentMarker(previousCurrent);
  }

  function send(command, value) {
    if (!socket || socket.readyState !== WebSocket.OPEN) return false;
    socket.send(command + "=" + value);
    return true;
  }

  function requestExtraSync() {
    if (extraSyncSent) return;
    extraSyncSent = true;
    clearTimeout(extraSyncTimer);
    if (!['system', 'settings'].includes(location.hash.slice(1))) {
      send("getsystem", 1);
      send("getrssi", 1);
    }
  }

  function updatePayload(id, value) {
    switch (id) {
      case "nameset":
        state.station = String(value || "");
        renderStation();
        break;
      case "meta":
        state.metadata = String(value || "");
        renderMetadata();
        break;
      case "volume": {
        const volume = Number(value);
        if (!Number.isInteger(volume) || volume < 0 || volume > 254) break;
        state.volume = volume;
        break;
      }
      case "volume100": {
        const volume = Number(value);
        if (!Number.isInteger(volume) || volume < 0 || volume > 100) break;
        state.volume100 = volume;
        if (awaitingVolume === volume) {
          awaitingVolume = null;
          clearTimeout(volumeAckTimer);
        }
        renderVolume();
        break;
      }
      case "muted":
        if (value === 0 || value === 1) {
          state.muted = value === 1;
          renderVolume();
        }
        break;
      case "maximumVolume": {
        const maximum = Number(value);
        if (!Number.isInteger(maximum) || maximum < 1 || maximum > 100) break;
        confirmVolumeSetting("maximumVolume", maximum);
        break;
      }
      case "startupMode": {
        const mode = Number(value);
        if (!Number.isInteger(mode) || (mode !== 0 && mode !== 1)) break;
        confirmVolumeSetting("startupMode", mode);
        break;
      }
      case "startupFixedVolume": {
        const volume = Number(value);
        if (!Number.isInteger(volume) || volume < 0 || volume > 100) break;
        confirmVolumeSetting("startupFixedVolume", volume);
        break;
      }
      case "bass":
      case "middle":
      case "trebble":
      case "balance": {
        const setting = Number(value);
        if (!Number.isInteger(setting)) break;
        const key = id === "trebble" ? "treble" : id;
        state[key] = setting;
        clearTimeout(audioControls[key].ackTimer);
        break;
      }
      case "rssi": {
        const rssi = Number(value);
        state.rssi = Number.isFinite(rssi) ? rssi : null;
        renderRssi();
        renderSystemInfo();
        break;
      }
      case "bitrate": {
        const bitrate = Number(value);
        state.bitrate = Number.isFinite(bitrate) && bitrate > 0 ? bitrate : null;
        renderStream();
        break;
      }
      case "fmt":
        state.codec = value && value !== "bitrate" ? String(value) : null;
        renderStream();
        break;
      case "playerwrap":
        state.playing = value === "playing" ? true : value === "stopped" ? false : null;
        renderPlaying();
        break;
      case "source":
        state.source = value ? String(value) : null;
        renderSource();
        break;
      default:
        break;
    }
  }

  function receive(raw) {
    let message;
    try {
      message = JSON.parse(raw);
    } catch (error) {
      console.warn("VoxOne: invalid WebSocket JSON", error);
      return;
    }
    if (advancedAudio.handleWsMessage(message)) return;
    if (message.event === "scrollSettings.result") {
      clearTimeout(scrollSettingsTimer);
      const requested = scrollSettingsPending;
      scrollSettingsSaving = false;
      scrollSettingsPending = null;
      if (message.ok === true && message.persisted === true &&
          message.runtimePublished === true && requested) {
        state.scrollEnabled = requested.enabled;
        state.scrollSpeed = requested.speed;
        state.scrollPauseMs = requested.pauseMs;
        state.scrollSettingsSource = "userSettings";
        state.scrollCoreActive = message.scrollCoreActive === true;
        scrollSettingsDirty = false;
        scrollSettingsFeedbackError = false;
        scrollSettingsFeedback = message.activeApplied === true
          ? (message.changed === true ? "Zapisano i zastosowano ustawienia."
            : "Ustawienia są już zapisane i aktywne.")
          : (message.changed === true ? "Zapisano ustawienia. Ten firmware nie stosuje ich aktywnie."
            : "Ustawienia są już zapisane. Ten firmware nie stosuje ich aktywnie.");
      } else {
        const errors = {
          invalid_value: "Urządzenie odrzuciło nieprawidłowe ustawienia.",
          unsupported_display: "Bieżący wyświetlacz nie obsługuje tych ustawień.",
          busy: "Urządzenie jest zajęte. Spróbuj ponownie.",
          storage_read_failed: "Nie udało się odczytać ustawień z pamięci.",
          storage_open_failed: "Nie udało się otworzyć pamięci ustawień.",
          storage_write_failed: "Nie udało się zapisać ustawień.",
          storage_commit_failed: "Nie udało się trwale zatwierdzić ustawień.",
          storage_verify_failed: "Weryfikacja zapisu ustawień nie powiodła się.",
          reload_failed: "Zapisano dane, ale przeładowanie ustawień nie powiodło się.",
          runtime_verify_failed: "Zapisano dane, ale runtime nie potwierdził ustawień."
        };
        scrollSettingsFeedbackError = true;
        scrollSettingsFeedback = errors[message.error] || "Nie udało się zapisać ustawień.";
      }
      renderDisplaySettings();
      return;
    }
    const status = message.webStatus;
    if (status && (status.source === "WEB" || status.source === "BT") &&
        ["name", "metadata", "artist", "title", "codec", "playback", "activeSource", "transport"]
          .every(key => typeof status[key] === "string") &&
        ["radio", "bt"].includes(status.activeSource) &&
        ["playing", "paused", "stopped", "unavailable"].includes(status.transport) &&
        Number.isInteger(status.bitrate) && Number.isInteger(status.sampleRate) &&
        typeof status.btConnected === "boolean" &&
        Array.isArray(status.availableSources) &&
        status.btModule && typeof status.btModule.online === "boolean" &&
        Number.isInteger(status.volume100) && status.volume100 >= 0 && status.volume100 <= 100 &&
        typeof status.muted === "boolean") {
      state.webStatus = status;
      state.volume100 = status.volume100;
      state.muted = status.muted;
      renderStatus();
      renderVolume();
      renderBtModule();
      renderUpdateFiles();
    }
    const systemInfo = message.systemInfo;
    if (systemInfo && typeof systemInfo === "object" &&
        ["mac", "capabilities"].every(key => typeof systemInfo[key] === "string") &&
        Number.isInteger(systemInfo.rssi) &&
        ["uptimeSeconds", "freeHeap", "minimumFreeHeap", "psramTotal", "psramFree"]
          .every(key => Number.isSafeInteger(systemInfo[key]) && systemInfo[key] >= 0)) {
      state.systemInfo = systemInfo;
      renderSystemInfo();
    }
    const networkInfo = message.networkInfo;
    if (networkInfo && typeof networkInfo.hostname === "string" &&
        typeof networkInfo.activeSsid === "string" && Array.isArray(networkInfo.profiles)) {
      const profiles = networkInfo.profiles.slice(0, 5).filter(profile =>
        profile && typeof profile.ssid === "string" && typeof profile.passwordSet === "boolean" &&
        Number.isInteger(profile.order) && profile.order >= 1 && profile.order <= 5)
        .map(profile => ({ssid: profile.ssid, passwordSet: profile.passwordSet, order: profile.order}));
      state.networkInfo = {
        hostname: networkInfo.hostname,
        activeSsid: networkInfo.activeSsid,
        profiles
      };
      renderNetworkInfo();
    }
    if (Array.isArray(message.payload)) {
      let toneChanged = false;
      for (const item of message.payload) {
        updatePayload(item.id, item.value);
        if (["bass", "middle", "trebble", "balance"].includes(item.id)) toneChanged = true;
      }
      if (toneChanged) renderAudio();
    }
    if (typeof message.current === "number") {
      const previousCurrent = state.current;
      state.current = Number.isInteger(message.current) ? message.current : null;
      wsCurrentSequence++;
      updateCurrentMarker(previousCurrent);
    }
    if (typeof message.ipaddr === "string") {
      state.ip = message.ipaddr;
      text("system-ip", state.ip || "—");
      renderFooter();
    }
    if (message.canFlip === 0 || message.canFlip === 1) {
      state.canFlip = message.canFlip === 1;
    }
    if (message.canBrightness === 0 || message.canBrightness === 1) {
      state.canBrightness = message.canBrightness === 1;
    }
    if (message.canBtTransport === 0 || message.canBtTransport === 1)
      state.canBtTransport = message.canBtTransport === 1;
    if (Number.isInteger(message.stationListTimeout) && message.stationListTimeout >= 0 && message.stationListTimeout <= 120)
      state.stationListTimeout = message.stationListTimeout;
    if (Number.isInteger(message.btTransportTimeout) && message.btTransportTimeout >= 0 && message.btTransportTimeout <= 120)
      state.btTransportTimeout = message.btTransportTimeout;
    if (Number.isInteger(message.br) && message.br >= 0 && message.br <= 100) {
      state.brightness = message.br;
      if (brightnessAwaiting === message.br) {
        brightnessAwaiting = null;
        clearTimeout(brightnessAckTimer);
      }
    }
    if (message.flip === 0 || message.flip === 1) {
      state.flip = message.flip === 1;
      flipPending = false;
      clearTimeout(flipTimer);
    }
    if (message.canVu === 0 || message.canVu === 1) state.canVu = message.canVu === 1;
    if (message.vu === 0 || message.vu === 1) {
      state.vu = message.vu === 1;
      if (vuAwaiting === state.vu) {
        vuAwaiting = null;
        clearTimeout(vuTimer);
      }
    }
    const scrollSnapshotValid = typeof message.canScrollSettings === "boolean" &&
      typeof message.scrollEnabled === "boolean" &&
      ["slow", "normal", "fast"].includes(message.scrollSpeed) &&
      scrollReadablePauseValues.includes(message.scrollPauseMs) &&
      ["rendererDefaults", "userSettings"].includes(message.scrollSettingsSource) &&
      typeof message.scrollCoreActive === "boolean";
    if (scrollSnapshotValid) {
      state.canScrollSettings = message.canScrollSettings;
      state.scrollEnabled = message.scrollEnabled;
      state.scrollSpeed = message.scrollSpeed;
      state.scrollPauseMs = message.scrollPauseMs;
      state.scrollSettingsSource = message.scrollSettingsSource;
      state.scrollCoreActive = message.scrollCoreActive;
      if (!message.canScrollSettings || !message.scrollCoreActive) {
        scrollSettingsDirty = false;
        scrollSettingsFeedback = "";
        scrollSettingsFeedbackError = false;
      }
    }
    if (message.canFlip === 0 || message.canFlip === 1 ||
        message.flip === 0 || message.flip === 1 ||
        message.canBrightness === 0 || message.canBrightness === 1 ||
        Number.isInteger(message.br) ||
        message.canVu === 0 || message.canVu === 1 ||
        message.vu === 0 || message.vu === 1 ||
        Number.isInteger(message.stationListTimeout) ||
        Number.isInteger(message.btTransportTimeout) ||
        message.canBtTransport === 0 || message.canBtTransport === 1 ||
        scrollSnapshotValid) renderDisplaySettings();
  }

  function connect() {
    if (!applicationAuthorized || leaving ||
        (socket && socket.readyState < WebSocket.CLOSING)) return;
    clearTimeout(reconnectTimer);
    state.connection = "connecting";
    renderConnection();
    const scheme = location.protocol === "https:" ? "wss://" : "ws://";
    const ws = new WebSocket(scheme + location.host + "/ws");
    socket = ws;
    ws.onopen = () => {
      if (socket !== ws) return;
      reconnectDelay = 1000;
      extraSyncSent = false;
      resetRuntime();
      state.connection = "connected";
      renderConnection();
      advancedAudio.connected();
      send("getwebstatus", 1);
      send("getindex", 1);
      send("getscreen", 1);
      extraSyncTimer = setTimeout(requestExtraSync, 1500);
      scheduleSystemInfoRefresh();
    };
    ws.onmessage = event => {
      if (socket === ws) receive(event.data);
    };
    ws.onerror = () => ws.close();
    ws.onclose = () => {
      if (socket !== ws) return;
      clearTimeout(extraSyncTimer);
      clearTimeout(systemInfoTimer);
      clearTimeout(volumeTimer);
      clearTimeout(volumeAckTimer);
      socket = null;
      state.connection = "disconnected";
      resetRuntime();
      advancedAudio.disconnected();
      renderBtModule();
      renderSystemInfo();
      renderNetworkInfo();
      renderFooter();
      for (const control of Object.values(audioControls)) {
        control.dragging = false;
        clearTimeout(control.ackTimer);
      }
      renderAudio();
      renderDisplaySettings();
      if (applicationAuthorized && !leaving) {
        reconnectTimer = setTimeout(connect, reconnectDelay);
        reconnectDelay = Math.min(reconnectDelay * 2, 15000);
      }
    };
  }

  function flashButton(button) {
    button.classList.add("is-pending");
    setTimeout(() => button.classList.remove("is-pending"), 600);
  }

  buttons.prev.addEventListener("click", () => {
    if (send("webtransport", "prev")) flashButton(buttons.prev);
  });
  buttons.play.addEventListener("click", () => {
    if (send("webtransport", "toggle")) flashButton(buttons.play);
  });
  buttons.next.addEventListener("click", () => {
    if (send("webtransport", "next")) flashButton(buttons.next);
  });
  sourceSelector.addEventListener("click", event => {
    const button = event.target.closest("button[data-source]");
    if (button && !button.disabled) send("source", button.dataset.source);
  });

  myStationsTab.addEventListener("click", () => showStationView(false));
  directoryTab.addEventListener("click", () => showStationView(true));
  directoryForm.addEventListener("submit", event => {
    event.preventDefault();
    searchDirectory();
  });
  directoryResults.addEventListener("click", async event => {
    const button = event.target.closest("button[data-directory-index]");
    if (!button || button.disabled || state.mutationInProgress) return;
    const station = directoryStations[Number(button.dataset.directoryIndex)];
    if (!station) return;
    button.disabled = true;
    button.textContent = "Dodawanie...";
    if (state.stationsStatus !== "ready" && !await loadStations()) {
      directoryMessage("Nie udało się pobrać listy własnych stacji.", true);
      button.disabled = false;
      button.textContent = "Dodaj";
      return;
    }
    const added = await mutateStation("add",
      { name: station.name, url: station.url, ovol: "0" }, "Dodano stację.");
    if (added) {
      button.textContent = "Dodano";
      directoryMessage("Dodano „" + station.name + "” do Moje stacje.");
    } else {
      button.disabled = false;
      button.textContent = "Dodaj";
      directoryMessage("Nie udało się dodać stacji. Sprawdź komunikat w Moje stacje.", true);
    }
  });
  stationSearch.addEventListener("input", () => {
    state.stationQuery = stationSearch.value;
    stationClear.disabled = state.stationQuery.length === 0;
    if (state.stationsStatus === "ready") renderStationList();
  });
  stationClear.addEventListener("click", () => {
    stationSearch.value = "";
    state.stationQuery = "";
    stationClear.disabled = true;
    if (state.stationsStatus === "ready") renderStationList();
    stationSearch.focus();
  });
  stationRetry.addEventListener("click", loadStations);
  stationAdd.addEventListener("click", () => openStationForm());
  stationImport.addEventListener("click", () => {
    if (!stationImport.disabled) stationImportFile.click();
  });
  stationExport.addEventListener("click", event => {
    if (stationExport.getAttribute("aria-disabled") === "true") event.preventDefault();
  });
  stationImportFile.addEventListener("change", () => {
    const file = stationImportFile.files[0];
    if (!file) {
      stationImportFile.value = "";
      return;
    }
    if (file.size === 0) {
      stationImportFile.value = "";
      setStationFeedback("Plik VoxOne Stations jest pusty.", true);
      return;
    }
    if (file.size > 192 * 1024) {
      stationImportFile.value = "";
      setStationFeedback(importErrorMessage(413), true);
      return;
    }
    stationImportDetails.textContent = file.name + " · " + file.size + " B";
    stationImportWarning.textContent =
      "Import zastąpi obecną listę stacji. Aktualna lista zostanie zachowana bezpiecznie do czasu zakończenia zapisu.";
    setStationFeedback("");
    stationImportDialog.showModal();
    renderStationActions();
    stationImportConfirm.focus();
  });
  stationImportCancel.addEventListener("click", () => stationImportDialog.close());
  stationImportConfirm.addEventListener("click", importPlaylist);
  stationImportDialog.addEventListener("cancel", event => {
    if (state.mutationInProgress) event.preventDefault();
  });
  stationImportDialog.addEventListener("close", () => {
    stationImportFile.value = "";
    renderStationActions();
  });
  stationCancel.addEventListener("click", () => stationDialog.close());
  stationDialog.addEventListener("cancel", event => {
    if (state.mutationInProgress) event.preventDefault();
  });
  stationDialog.addEventListener("close", () => {
    state.editorNumber = null;
    stationFormError.textContent = "";
  });
  stationForm.addEventListener("submit", event => {
    event.preventDefault();
    if (state.mutationInProgress) return;
    const fields = validateStationForm();
    if (fields.error) {
      setStationFeedback(fields.error, true);
      return;
    }
    if (state.editorNumber === null) {
      mutateStation("add", fields, "Dodano stację.");
    } else {
      mutateStation("edit", { id: state.stations[state.editorNumber - 1].id, ...fields }, "Zapisano stację.");
    }
  });
  stationList.addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button || button.disabled || !stationList.contains(button)) return;
    const number = Number(button.dataset.number);
    if (!Number.isInteger(number) || number < 1 || number > state.count) return;
    if (button.classList.contains("station-play")) {
      if (send("playstation", number)) flashButton(button);
      return;
    }
    if (state.loading || state.mutationInProgress || state.stationsStatus !== "ready") return;
    const station = state.stations[number - 1];
    if (!station || station.number !== number) return;
    switch (button.dataset.action) {
      case "metadata":
        mutateStation("metadata", { id: station.id, swapArtistTitle: station.swapArtistTitle ? "0" : "1" },
          station.swapArtistTitle ? "Wyłączono zamianę artysty i utworu." : "Włączono zamianę artysty i utworu.");
        break;
      case "edit":
        openStationForm(number);
        break;
      case "delete": {
        const activeNote = number === state.current ? "\nTo jest aktualnie odtwarzana stacja." : "";
        if (window.confirm("Usunąć stację „" + station.name + "”?" + activeNote)) {
          mutateStation("delete", { id: station.id }, "Usunięto stację.");
        }
        break;
      }
      case "up":
      case "down": {
        const target = number + (button.dataset.action === "up" ? -1 : 1);
        if (target >= 1 && target <= state.count) {
          mutateStation("reorder", { id: station.id, targetPosition: String(target) }, "Zmieniono kolejność stacji.");
        }
        break;
      }
      default:
        break;
    }
  });
  function sendPendingVolume() {
    clearTimeout(volumeTimer);
    if (pendingVolume === null) return;
    if (send("vol100", pendingVolume)) lastVolumeSentAt = performance.now();
    pendingVolume = null;
  }

  for (const button of muteButtons) button.addEventListener("click", () => {
    if (button.disabled) return;
    send("mute", state.muted ? 0 : 1);
  });

  for (const slider of volumeSliders) {
    slider.addEventListener("input", () => {
      if (state.volume100 === null || state.connection !== "connected") return;
      draggingVolume = true;
      activeVolumeSlider = slider;
      pendingVolume = Number(slider.value);
      const wait = 120 - (performance.now() - lastVolumeSentAt);
      if (wait <= 0) sendPendingVolume();
      else {
        clearTimeout(volumeTimer);
        volumeTimer = setTimeout(sendPendingVolume, wait);
      }
    });

    slider.addEventListener("change", () => {
      if (!draggingVolume || activeVolumeSlider !== slider) return;
      const finalVolume = Number(slider.value);
      draggingVolume = false;
      activeVolumeSlider = null;
      pendingVolume = finalVolume;
      awaitingVolume = finalVolume;
      sendPendingVolume();
      clearTimeout(volumeAckTimer);
      volumeAckTimer = setTimeout(() => {
        awaitingVolume = null;
        renderVolume();
      }, 1500);
    });
  }

  maximumVolumeSlider.addEventListener("input", () => {
    if (maximumVolumeSlider.disabled) return;
    volumeSettingDragging.maximumVolume = true;
    maximumVolumeValue.textContent = maximumVolumeSlider.value;
  });
  maximumVolumeSlider.addEventListener("change", () => {
    if (maximumVolumeSlider.disabled) return;
    const value = Number(maximumVolumeSlider.value);
    volumeSettingDragging.maximumVolume = false;
    if (!Number.isInteger(value) || value < 1 || value > 100) {
      renderVolumeSettings();
      return;
    }
    sendVolumeSetting("maximumVolume", "maximumvolume", value);
  });

  flipScreenToggle.addEventListener("change", () => {
    if (!state.canFlip || state.flip === null ||
        !send("flipscreen", flipScreenToggle.checked ? 1 : 0)) {
      renderDisplaySettings();
      return;
    }
    flipPending = true;
    clearTimeout(flipTimer);
    flipTimer = setTimeout(() => {
      flipPending = false;
      renderDisplaySettings();
      send("getscreen", 1);
    }, 2000);
    renderDisplaySettings();
  });

  vuMeterToggle.addEventListener("change", () => {
    const requested = vuMeterToggle.checked;
    if (!state.canVu || state.vu === null || !send("vumeter", requested ? 1 : 0)) {
      renderDisplaySettings();
      return;
    }
    vuAwaiting = requested;
    clearTimeout(vuTimer);
    vuTimer = setTimeout(() => {
      vuAwaiting = null;
      renderDisplaySettings();
      send("getsystem", 1);
    }, 2000);
    renderDisplaySettings();
  });

  function sendPendingBrightness() {
    clearTimeout(brightnessTimer);
    if (brightnessPending === null) return false;
    const value = brightnessPending;
    brightnessPending = null;
    if (!send("dim", value)) return false;
    lastBrightnessSentAt = performance.now();
    return true;
  }

  brightnessSlider.addEventListener("input", () => {
    if (!state.canBrightness || state.connection !== "connected") return;
    brightnessDragging = true;
    brightnessPending = Number(brightnessSlider.value);
    brightnessValue.textContent = brightnessPending + "%";
    const wait = 120 - (performance.now() - lastBrightnessSentAt);
    if (wait <= 0) sendPendingBrightness();
    else {
      clearTimeout(brightnessTimer);
      brightnessTimer = setTimeout(sendPendingBrightness, wait);
    }
  });

  brightnessSlider.addEventListener("change", () => {
    if (!state.canBrightness || state.connection !== "connected") return;
    brightnessDragging = false;
    brightnessPending = Number(brightnessSlider.value);
    brightnessAwaiting = brightnessPending;
    if (!sendPendingBrightness()) {
      brightnessAwaiting = null;
      renderDisplaySettings();
      return;
    }
    clearTimeout(brightnessAckTimer);
    brightnessAckTimer = setTimeout(() => {
      brightnessAwaiting = null;
      renderDisplaySettings();
      send("getscreen", 1);
    }, 2000);
    renderDisplaySettings();
  });

  function saveIdleTimeout(input, key, command) {
    const value = Number(input.value);
    if (input.value.trim() === "" || !Number.isInteger(value) || value < 0 || value > 120 ||
        !send(command, value)) {
      input.value = state[key] === null ? "" : String(state[key]);
      return;
    }
    input.blur();
    setTimeout(() => send("getscreen", 1), 500);
  }

  stationListTimeoutInput.addEventListener("change", () =>
    saveIdleTimeout(stationListTimeoutInput, "stationListTimeout", "stationlisttimeout"));
  btTransportTimeoutInput.addEventListener("change", () =>
    saveIdleTimeout(btTransportTimeoutInput, "btTransportTimeout", "bttransporttimeout"));

  function scrollSettingsSelection() {
    const enabled = scrollEnabledSelect.value === "true" ? true :
      scrollEnabledSelect.value === "false" ? false : null;
    const speed = ["slow", "normal", "fast"].includes(scrollSpeedSelect.value)
      ? scrollSpeedSelect.value : null;
    const pauseMs = Number(scrollPauseSelect.value);
    if (enabled === null || speed === null ||
        !scrollWritablePauseValues.includes(pauseMs)) return null;
    return { enabled, speed, pauseMs };
  }

  function updateScrollSettingsDirty() {
    const selected = scrollSettingsSelection();
    scrollSettingsFeedback = "";
    scrollSettingsFeedbackError = false;
    scrollSettingsDirty = selected !== null &&
      (selected.enabled !== state.scrollEnabled || selected.speed !== state.scrollSpeed ||
       selected.pauseMs !== state.scrollPauseMs);
    renderDisplaySettings();
  }

  for (const control of [scrollEnabledSelect, scrollPauseSelect, scrollSpeedSelect])
    control.addEventListener("change", updateScrollSettingsDirty);

  scrollSettingsForm.addEventListener("submit", event => {
    event.preventDefault();
    if (!state.canScrollSettings || !state.scrollCoreActive ||
        state.connection !== "connected" || scrollSettingsSaving || !scrollSettingsDirty) {
      renderDisplaySettings();
      return;
    }
    const selected = scrollSettingsSelection();
    if (!selected) {
      scrollSettingsFeedback = "Wybierz poprawne wartości wszystkich trzech ustawień.";
      scrollSettingsFeedbackError = true;
      renderDisplaySettings();
      return;
    }
    const value = String(selected.enabled) + "," + selected.speed + "," + selected.pauseMs;
    if (!send("scrollsettings", value)) {
      scrollSettingsFeedback = "Brak połączenia z urządzeniem. Ustawienia nie zostały wysłane.";
      scrollSettingsFeedbackError = true;
      renderDisplaySettings();
      return;
    }
    scrollSettingsSaving = true;
    scrollSettingsPending = selected;
    scrollSettingsFeedback = "";
    scrollSettingsFeedbackError = false;
    clearTimeout(scrollSettingsTimer);
    scrollSettingsTimer = setTimeout(() => {
      scrollSettingsSaving = false;
      scrollSettingsPending = null;
      scrollSettingsFeedback = "Brak potwierdzenia zapisu. Odczytaj ponownie stan urządzenia.";
      scrollSettingsFeedbackError = true;
      renderDisplaySettings();
      send("getscreen", 1);
    }, 6000);
    renderDisplaySettings();
  });

  rtcNtpInterval.addEventListener("change", () => saveTimeInterval(rtcNtpInterval, "timeint", 1, 10080));
  rtcWriteInterval.addEventListener("change", () => saveTimeInterval(rtcWriteInterval, "timeintrtc", 1, 1000));
  rtcSyncNow.addEventListener("click", syncTimeNow);

  startupModeSelect.addEventListener("change", () => {
    if (startupModeSelect.disabled) return;
    const mode = Number(startupModeSelect.value);
    if (mode !== 0 && mode !== 1) {
      renderVolumeSettings();
      return;
    }
    sendVolumeSetting("startupMode", "startupmode", mode);
  });

  startupFixedSlider.addEventListener("input", () => {
    if (startupFixedSlider.disabled) return;
    volumeSettingDragging.startupFixedVolume = true;
    startupFixedValue.textContent = startupFixedSlider.value;
  });
  startupFixedSlider.addEventListener("change", () => {
    if (startupFixedSlider.disabled) return;
    const value = Number(startupFixedSlider.value);
    volumeSettingDragging.startupFixedVolume = false;
    if (!Number.isInteger(value) || value < 0 || value > 100) {
      renderVolumeSettings();
      return;
    }
    sendVolumeSetting("startupFixedVolume", "startupfixedvolume", value);
  });

  for (const control of Object.values(audioControls)) {
    control.dragging = false;
    control.slider.addEventListener("input", () => {
      if (!control.slider.disabled) control.dragging = true;
    });
    control.slider.addEventListener("change", () => {
      if (control.slider.disabled) return;
      const value = Number(control.slider.value);
      control.dragging = false;
      if (!Number.isInteger(value) || value < Number(control.slider.min) ||
          value > Number(control.slider.max) || !send(control.command, value)) {
        renderAudio();
      } else {
        clearTimeout(control.ackTimer);
        control.ackTimer = setTimeout(renderAudio, 1500);
      }
    });
  }

  for (const button of tonePresetButtons) {
    button.addEventListener("click", () => {
      if (button.disabled) return;
      const values = tonePresets[button.dataset.tonePreset];
      if (values) send("tone", values.join(","));
    });
  }

  window.addEventListener("hashchange", showTab);
  window.addEventListener("pageshow", event => {
    if (event.persisted) {
      showStartupTab();
      refreshSecurityState();
    }
  });
  securitySetupForm.addEventListener("change", event => {
    if (event.target.name === "security-mode") renderSecurityModeFields();
  });
  securitySetupPassword.addEventListener("input", () => {
    securityWeakWarning.hidden = !securityPasswordInfo(securitySetupPassword.value).weak;
    setSecurityMessage(securitySetupMessage, "", false);
  });
  securitySetupRepeat.addEventListener("input", () =>
    setSecurityMessage(securitySetupMessage, "", false));
  securitySetupForm.addEventListener("submit", submitSecuritySetup);
  securitySetupLater.addEventListener("click", () => showApplication({
    warning: "Ochrona panelu nie została jeszcze skonfigurowana."
  }));
  securityLoginForm.addEventListener("submit", submitSecurityLogin);
  securityLoginPassword.addEventListener("input", () =>
    setSecurityMessage(securityLoginMessage, "", false));
  securityLogout.addEventListener("click", logoutSecuritySession);
  securityManagementMode.addEventListener("change", renderSecurityManagementFields);
  securityManagementForm.addEventListener("submit", submitSecurityManagement);
  for (const button of securityPasswordToggles) {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.passwordTarget);
      setPasswordVisible(input, input.type === "password", true);
    });
  }
  for (const [target, image] of Object.entries(updateImages)) {
    image.file.addEventListener("change", renderUpdateFiles);
    image.button.addEventListener("click", () => uploadUpdateImage(target));
  }
  updateBtFile.addEventListener("change", renderUpdateFiles);
  updateBtButton.addEventListener("click", uploadBtFirmware);
  setInterval(pollBtUpdate, 1500);
  rebootButton.addEventListener("click", () => {
    if (!rebootStarted) rebootDialog.showModal();
  });
  rebootCancel.addEventListener("click", () => rebootDialog.close());
  rebootConfirm.addEventListener("click", rebootDevice);
  configBackupButton.addEventListener("click", downloadConfigBackup);
  configRestoreFile.addEventListener("change", () => {
    const file = configRestoreFile.files[0];
    configRestoreName.textContent = file ? file.name : "Nie wybrano pliku.";
    configRestoreButton.disabled = !file || configTransferBusy;
    configRestoreRestart.hidden = true;
    setConfigTransferStatus(configRestoreStatus, "");
  });
  configRestoreButton.addEventListener("click", restoreConfigBackup);
  configRestoreRestart.addEventListener("click", () => {
    if (!rebootStarted) rebootDialog.showModal();
  });
  mqttForm.addEventListener("submit", saveMqttConfig);
  hardwareForm.addEventListener("submit", event => {
    event.preventDefault();
    saveHardwareConfig(true);
  });
  hardwareDisplay.addEventListener("change", () => {
    setHardwareFeedback("");
    renderHardwareFormState();
  });
  hardwareInput.addEventListener("change", () => {
    setHardwareFeedback("");
    renderHardwareFormState();
  });
  mqttEnabled.addEventListener("change", updateMqttFormState);
  mqttPassword.addEventListener("input", () => {
    if (mqttPassword.value) mqttClearPassword.checked = false;
  });
  mqttClearPassword.addEventListener("change", () => {
    if (mqttClearPassword.checked) mqttPassword.value = "";
  });
  mqttForm.querySelectorAll('input[name="mqtt-root-mode"]').forEach(input => input.addEventListener("change", renderMqttRoot));
  haName.addEventListener("input", renderHaYaml);
  haCopy.addEventListener("click", copyHaYaml);
  window.addEventListener("online", () => {
    if (applicationAuthorized && !socket) connect();
  });
  window.addEventListener("beforeunload", () => {
    leaving = true;
    clearTimeout(reconnectTimer);
    if (socket) socket.close();
  });
  renderIdentity();
  renderUpdateFiles();
  renderConnection();
  showStartupTab();
  refreshSecurityState();
})();
